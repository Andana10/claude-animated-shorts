# Kenapa Hal Sehari-hari Bisa Begitu?

Use the repository skill at `.agents/skills/indonesian-animated-shorts/SKILL.md` when producing an episode. Start with the episode file and the grounded mechanism. Keep Indonesian narration, burned-in captions, SRT, shot list, and sound events aligned to the same 30 fps clock.

- `src/engine` contains reusable character, post, camera, caption, and mesh code. Episode choreography is in `src/episodes/NNN`.
- Keep visual updates derived from the absolute Remotion frame. Test nonconsecutive stills to catch order-dependent animation state.
- Update the episode JSON before changing generated documents. Run `node scripts/episode.mjs prepare episodes/NNN` and `npm run check`.
- For picture changes, inspect at least one frame in each changed shot and a moving excerpt around difficult actions. Confirm the whole preview with FFprobe and `scripts/qa.mjs`.
- Use local or licensed original assets. Keep upstream attribution and the MIT notice. Review any branded placement or product statement against the episode's source notes.
- Save working renders under `renders/`. Record the actual resolution, frame count, duration, audio status, and backend for any delivered media.
