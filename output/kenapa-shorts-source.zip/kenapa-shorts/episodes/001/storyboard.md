# Storyboard · Kenapa Kabel Charger Selalu Rusak di Bagian Ini?

Durasi 54 detik. Frame akhir tiap shot bersifat eksklusif.

| Shot | Waktu | Frame | Aksi dan kamera | SFX (frame) |
| --- | --- | --- | --- | --- | --- |
| 1 · Kabel kok putus? | 00:00:00,000–00:00:05,000 | 0–150 | Kamera menyusur meja ke ponsel Kiko. Indikator isi daya berkedip, lalu hilang. Kiko melirik pangkal kabel. | charge 14, drop 52, drop 95 |
| 2 · Tekuk. Balik. Ulang. | 00:00:05,000–00:00:10,300 | 150–309 | Tiga ayunan ujung kabel mendemonstrasikan tekukan yang sama. Kamera meluncur mendekati batas rumah konektor. | flex 176, flex 224, flex 272 |
| 3 · Beban terkumpul | 00:00:10,300–00:00:15,400 | 309–462 | Macro samping dengan pita kisi yang merenggang di sisi luar tekukan. Lingkaran penunjuk mengunci zona transisi kaku-lentur. | sweep 324, flex 403 |
| 4 · Di balik selubung | 00:00:15,400–00:00:20,700 | 462–621 | Kamera melewati bibir selubung. Potongan memisahkan jaket luar, isolasi berwarna, dan ilustrasi serabut konduktor. | sweep 474, charge 548 |
| 5 · Kelelahan logam | 00:00:20,700–00:00:26,900 | 621–807 | Reverse angle pada serabut tembaga. Tekukan berulang, retak kecil tampak pada satu serabut, lalu celah muncul bertahap. | flex 654, snap 719, snap 759, snap 783 |
| 6 · Luar utuh. Dalam putus. | 00:00:26,900–00:00:32,300 | 807–969 | Match cut dari serabut yang putus ke kabel berjaket utuh. Kamera bergerak ke indikator yang kehilangan daya. | sweep 817, drop 889 |
| 7 · Pegang kepalanya | 00:00:32,300–00:00:37,600 | 969–1128 | Tangan Kiko masuk ke macro, memegang rumah konektor lalu menariknya lurus. Kabel mengikuti gerakan konektor. | click 1004, unplug 1067 |
| 8 · Beri ruang melengkung | 00:00:37,600–00:00:42,900 | 1128–1287 | Pandangan dari atas mengikuti kabel yang beralih dari sudut sempit ke lengkung lebar, dengan klip meja netral sebagai opsi penataan. | sweep 1142, click 1241 |
| 9 · Anyaman ≠ kebal | 00:00:42,900–00:00:48,100 | 1287–1443 | Orbit macro melintasi tekstur anyaman dan pelindung lentur pangkal. Kabel tetap menekuk bersama lapisan luarnya. | sweep 1303, flex 1386 |
| 10 · Rusak? Ganti. | 00:00:48,100–00:00:54,000 | 1443–1620 | Kiko menyingkirkan kabel sobek yang sudah dilepas. Kabel pengganti terpasang dengan lengkung longgar. Indikator hijau bertahan. | drop 1465, unplug 1536, charge 1579 |
