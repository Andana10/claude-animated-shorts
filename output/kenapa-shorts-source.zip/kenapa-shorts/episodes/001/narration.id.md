# Kenapa Kabel Charger Selalu Rusak di Bagian Ini?

Narasi Indonesia · 54 detik · 30 fps

Nada penasaran dan santai. Beri jeda pendek setelah pertanyaan pembuka dan sebelum kalimat terakhir.

## 00:00:00,000 · Kabel kok putus?

Lho, kok ngecasnya putus-nyambung? Lagi-lagi, masalahnya di dekat colokan.

## 00:00:05,000 · Tekuk. Balik. Ulang.

Sambil ngecas, kabel sering ikut ketekuk. Dan tekukannya berulang di titik yang sama.

## 00:00:10,300 · Beban terkumpul

Konektornya kaku, kabelnya lentur. Di perbatasannya, tegangan mekanis bisa terkumpul.

## 00:00:15,400 · Di balik selubung

Coba intip bagian dalamnya. Ada serabut tembaga tipis yang ikut tertekuk.

## 00:00:20,700 · Kelelahan logam

Tekukan berulang bisa bikin retak kecil. Retaknya membesar sampai serabut putus. Ini kelelahan logam.

## 00:00:26,900 · Luar utuh. Dalam putus.

Luarnya bisa kelihatan utuh. Tapi kalau jalur di dalam putus, daya bisa terhenti.

## 00:00:32,300 · Pegang kepalanya

Pas mencabut, pegang kepala konektornya. Tarik lurus. Jangan tarik kabelnya.

## 00:00:37,600 · Beri ruang melengkung

Sisakan ruang buat lengkungan yang longgar. Klip meja opsional, supaya kabel nggak ketarik.

## 00:00:42,900 · Anyaman ≠ kebal

Pelindung pangkal yang lentur bisa menyebar tekukan. Kabel beranyam pun tetap bisa rusak.

## 00:00:48,100 · Rusak? Ganti.

Kalau kabel tampak rusak, hentikan pemakaian. Ganti kabelnya. Biar ngecas, tanpa akrobat.
