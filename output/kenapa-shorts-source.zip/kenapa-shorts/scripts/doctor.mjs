import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {openBrowser} from '@remotion/renderer';
import {REVISION} from 'three';
import {browserOptions,run} from './platform.mjs';

const settings=await browserOptions();
const temporary=await mkdtemp(join(tmpdir(),'kenapa-doctor-'));
let browser;
try {
  console.log(`Node ${process.version} · Three.js r${REVISION}`);
  if(settings.browserExecutable) console.log(run(settings.browserExecutable,['--version'],{capture:true}));
  browser=await openBrowser('chrome',settings);
  const page=await browser.newPage({context:()=>null,logLevel:'error',indent:false,pageIndex:0,onBrowserLog:null,onLog:()=>{}});
  const probe=await page.evaluate(()=>{
    const canvas=document.createElement('canvas');
    canvas.width=canvas.height=16;
    const gl=canvas.getContext('webgl2');
    if(!gl) return null;
    const debug=gl.getExtension('WEBGL_debug_renderer_info');
    gl.clearColor(.25,.5,.75,1);
    gl.clear(gl.COLOR_BUFFER_BIT);
    const pixels=new Uint8Array(4);
    gl.readPixels(0,0,1,1,gl.RGBA,gl.UNSIGNED_BYTE,pixels);
    return {version:gl.getParameter(gl.VERSION),renderer:debug?gl.getParameter(debug.UNMASKED_RENDERER_WEBGL):null,pixels:[...pixels]};
  });
  if(!probe || probe.pixels.some((v,i)=>Math.abs(v-[64,128,191,255][i])>1)) throw new Error(`WebGL2 readback failed: ${JSON.stringify(probe)}`);
  console.log('WebGL2 readback',probe);
  console.log(run('ffmpeg',['-version'],{capture:true}).split('\n')[0]);
  const out=join(temporary,'encode.mp4');
  run('ffmpeg',['-v','error','-f','lavfi','-i','testsrc2=s=96x160:r=30:d=0.4','-c:v','libx264','-pix_fmt','yuv420p',out]);
  console.log(run('ffprobe',['-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,r_frame_rate,nb_frames','-of','compact',out],{capture:true}));
} finally {
  if(browser) await browser.close({silent:true});
  await rm(temporary,{recursive:true,force:true});
}
