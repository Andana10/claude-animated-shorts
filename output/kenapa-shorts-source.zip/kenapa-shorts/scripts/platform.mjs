import {access,mkdir} from 'node:fs/promises';
import {constants} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {resolve} from 'node:path';

export function run(executable,args,{capture=false,input}={}) {
  const child = spawnSync(executable,args,{encoding:'utf8',input,maxBuffer:32*1024*1024,stdio:['pipe',capture?'pipe':'inherit',capture?'pipe':'inherit']});
  if (child.error || child.status !== 0) {
    throw new Error(`${executable} failed (${child.status ?? child.signal ?? 'spawn'}): ${child.error?.message ?? child.stderr ?? ''}`);
  }
  return child.stdout?.trim() ?? '';
}

export async function browserOptions() {
  const linux = process.platform==='linux';
  if(linux) {
    for(const [key,name] of [['XDG_CACHE_HOME','cache'],['XDG_CONFIG_HOME','config'],['XDG_DATA_HOME','data']]) {
      if(process.env[key]) continue;
      const folder=resolve('.cache','browser',name);
      await mkdir(folder,{recursive:true});
      process.env[key]=folder;
    }
  }
  const gl = process.env.RENDER_GL || (linux ? 'swangle' : 'angle');
  const override = process.env.BROWSER_EXECUTABLE;
  const candidates = linux ? ['/usr/bin/chromium','/usr/bin/google-chrome','/usr/bin/chromium-browser'] : [];
  let executable = override || null;
  if (!override) {
    for (const candidate of candidates) {
      if (await access(candidate,constants.X_OK).then(()=>true,()=>false)) {executable=candidate; break;}
    }
  } else await access(override,constants.X_OK);
  return {
    browserExecutable:executable,
    chromeMode:executable?'chrome-for-testing':'headless-shell',
    chromiumOptions:{gl,enableMultiProcessOnLinux:linux,flags:{'disable-dev-shm-usage':true}},
  };
}
