import {spawnSync} from 'node:child_process';
import {mkdir,writeFile} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {readEpisode} from './episode.mjs';
import {run} from './platform.mjs';

const [epDir, inputPath, output='renders/qa'] = process.argv.slice(2);
if(!epDir) throw new Error('Usage: node scripts/qa.mjs <episode-directory> [video] [report-directory]');
const ep=await readEpisode(epDir);
const path=inputPath ?? `renders/episode-${ep.id}-preview.mp4`;
const video=resolve(path);
const report=resolve(output);
const meta=JSON.parse(run('ffprobe',['-v','error','-show_streams','-show_format','-of','json',video],{capture:true}));
const picture=meta.streams.find(s=>s.codec_type==='video');
const audio=meta.streams.find(s=>s.codec_type==='audio');
const seconds=ep.durationFrames/ep.fps;
if(picture?.codec_name!=='h264' || !['yuv420p','yuvj420p'].includes(picture.pix_fmt) ||
  ![[540,960],[1080,1920]].some(([w,h])=>w===picture.width && h===picture.height) ||
  picture.avg_frame_rate!==`${ep.fps}/1` || Number(picture.nb_frames)!==ep.durationFrames ||
  Math.abs(Number(meta.format.duration)-seconds)>.085) throw new Error('Unexpected H.264 video format or duration');
if(process.env.SILENT && audio) throw new Error('Expected a silent export');
if(!process.env.SILENT && (!audio || audio.codec_name!=='aac' || audio.channels!==2 ||
  audio.sample_rate!=='48000' || Math.abs(Number(audio.duration)-seconds)>.085)) {
  throw new Error('Expected a 48 kHz stereo AAC track aligned to the picture. Use SILENT=1 for a silent export.');
}

const videoChecks=spawnSync('ffmpeg',['-hide_banner','-nostats','-i',video,'-an','-vf',
  'scale=270:480,blackdetect=d=0.1:pix_th=0.1,freezedetect=n=-55dB:d=0.55','-f','null','-'],{encoding:'utf8',maxBuffer:2*1024*1024});
if(videoChecks.status!==0) throw new Error(videoChecks.error?.message ?? videoChecks.stderr);
const problems=videoChecks.stderr.split('\n').filter(line=>/black_start:|freeze_start:/.test(line));
const audioChecks=audio?spawnSync('ffmpeg',['-hide_banner','-nostats','-i',video,'-vn','-af','volumedetect','-f','null','-'],{encoding:'utf8'}):null;
if(audioChecks && audioChecks.status!==0) throw new Error(audioChecks.error?.message ?? audioChecks.stderr);
const peak=audioChecks?.stderr.match(/max_volume:\s*(-?[\d.]+) dB/)?.[1];
if(audio && (peak===undefined || Number(peak)<-30 || Number(peak)>=0)) problems.push('AAC peak outside the expected range');
const frames=ep.shots.map(shot=>Math.floor((shot.start+shot.end)/2));
const filter=`select='${frames.map(frame=>`eq(n,${frame})`).join('+')}',scale=216:384,tile=5x${Math.ceil(frames.length/5)}:padding=7:margin=7:color=0x172337`;
const sheet=resolve(report,'contact-sheet.jpg');
await mkdir(dirname(sheet),{recursive:true});
run('ffmpeg',['-v','error','-y','-i',video,'-an','-vf',filter,'-frames:v','1','-update','1','-q:v','3',sheet]);
const result={file:path,picture:{codec:picture.codec_name,pixelFormat:picture.pix_fmt,width:picture.width,height:picture.height,fps:ep.fps,frames:Number(picture.nb_frames),seconds},
  audio:audio?{codec:audio.codec_name,sampleRate:Number(audio.sample_rate),channels:audio.channels,peakDbfs:Number(peak)}:null,
  framesReviewed:frames,problems};
await writeFile(resolve(report,'verification.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
if(problems.length) process.exitCode=1;
