import {copyFile,mkdir,mkdtemp,readFile,rename,rm,writeFile} from 'node:fs/promises';
import {join,resolve} from 'node:path';
import {tmpdir} from 'node:os';
import {readEpisode} from './episode.mjs';
import {run} from './platform.mjs';

const episodeDir=process.argv[2];
if(!episodeDir) throw new Error('Usage: node scripts/voice.mjs <episode-directory>');
const ep=await readEpisode(episodeDir);
const target=resolve('public',`episode-${ep.id}`);
const temp=await mkdtemp(join(tmpdir(),'kenapa-audio-'));
const sampleRate=48000;
const length=ep.durationFrames * sampleRate / ep.fps;
const voice=new Float32Array(length);
const left=new Float32Array(length);
const right=new Float32Array(length);
const toSample=frame=>Math.round(frame*sampleRate/ep.fps);
const tone=x=>Math.sin(x*2*Math.PI);
const db=amplitude=>10**(amplitude/20);

function addCue(frame,name,seed) {
  const forms={
    charge:[.30,1046,1568,.10], drop:[.22,440,190,.12], flex:[.25,180,103,.11],
    sweep:[.36,160,350,.08], snap:[.15,540,247,.145], click:[.13,820,692,.13],
    unplug:[.20,440,190,.13],
  };
  const [duration,base,endpoint,level]=forms[name];
  const start=toSample(frame);
  const samples=Math.round(duration*sampleRate);
  const pan=((seed%5)-2)*.085;
  let noise=0;
  let phase=0;
  for(let i=0;i<samples && i+start<length;i++) {
    const t=i/sampleRate;
    const w=t/duration;
    seed=(Math.imul(seed,1664525)+1013904223)>>>0;
    noise=noise*.56+.44*(seed/0x80000000-1);
    phase+=(base+(endpoint-base)*w)/sampleRate;
    const env=Math.min(t/(name==='sweep'?.11:.007),1)*Math.exp(-w*(name==='sweep'?2.8:5.7))*(1-w);
    const noisy=['sweep','snap','unplug','click'].includes(name);
    const value=level*env*(.74*tone(phase)+.15*tone(phase*1.524)+(noisy?.6:.08)*noise);
    left[i+start]+=value*(1-pan);
    right[i+start]+=value*(1+pan);
  }
}

function packWav(channels) {
  const data=Buffer.alloc(44+length*2*channels.length);
  data.write('RIFF',0); data.writeUInt32LE(data.length-8,4); data.write('WAVEfmt ',8);
  data.writeUInt32LE(16,16);data.writeUInt16LE(1,20);data.writeUInt16LE(channels.length,22);
  data.writeUInt32LE(sampleRate,24);data.writeUInt32LE(sampleRate*2*channels.length,28);
  data.writeUInt16LE(2*channels.length,32);data.writeUInt16LE(16,34);
  data.write('data',36);data.writeUInt32LE(data.length-44,40);
  for(let i=0;i<length;i++) for(let c=0;c<channels.length;c++) {
    data.writeInt16LE(Math.round(Math.max(-1,Math.min(1,channels[c][i]))*32767),44+(i*channels.length+c)*2);
  }
  return data;
}

try {
  const espeak=process.env.ESPEAK_BIN || 'espeak-ng';
  const espeakArgs=process.env.ESPEAK_DATA ? ['--path='+process.env.ESPEAK_DATA] : [];
  const existing=process.env.VOICE_WAV ? resolve(process.env.VOICE_WAV) : null;
  const cues=ep.shots.flatMap(s=>s.cues);
  if(existing) {
    const raw=join(temp,'recorded.s16');
    const seconds=Number(run('ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',existing],{capture:true}));
    if (!Number.isFinite(seconds) || seconds>ep.durationFrames/ep.fps+.035) throw new Error('VOICE_WAV must be aligned and at most one frame longer than the episode');
    run('ffmpeg',['-v','error','-i',existing,'-vn','-ac','1','-ar',String(sampleRate),'-f','s16le',raw]);
    const pcm=await readFile(raw);
    for(let i=0;i<length && i<pcm.length/2;i++) voice[i]=pcm.readInt16LE(i*2)/32768;
  } else {
    const voices=run(espeak,[...espeakArgs,'--voices=id'],{capture:true});
    if(!/\bid\s+.*Indonesian/i.test(voices)) throw new Error('The installed eSpeak NG lacks Indonesian. Supply VOICE_WAV or use SILENT=1.');
    for (const [i,cue] of cues.entries()) {
      const a=toSample(cue.start), b=toSample(cue.end);
      const dur=(b-a)/sampleRate-.085;
      const wav=join(temp,`${i}.wav`);
      const raw=join(temp,`${i}.s16`);
      run(espeak,[...espeakArgs,'-v','id+f3','-s','166','-p','43','-a','84','-z','-w',wav,'--stdin'],{input:cue.text+'\n'});
      const sourceSeconds=Number(run('ffprobe',['-v','error','-show_entries','format=duration','-of','default=nw=1:nk=1',wav],{capture:true}));
      if(!Number.isFinite(sourceSeconds)||sourceSeconds<=0) throw new Error(`Empty Indonesian speech at frame ${cue.start}`);
      const tempo=Math.max(1.00,sourceSeconds/dur);
      run('ffmpeg',['-v','error','-i',wav,'-af',`atempo=${tempo.toFixed(6)},highpass=f=85,lowpass=f=9600,acompressor=threshold=0.22:ratio=2.1:attack=8:release=65`,
        '-ac','1','-ar',String(sampleRate),'-f','s16le',raw]);
      const pcm=await readFile(raw);
      const start=a+Math.round(.028*sampleRate);
      const n=Math.min(pcm.length/2,b-start);
      for(let j=0;j<n;j++) {
        const fade=Math.min(j/320,(n-j)/384,1);
        voice[start+j]=fade*pcm.readInt16LE(j*2)/32768;
      }
      console.log(`Cue ${i+1} · frame ${cue.start} · ${(n/sampleRate).toFixed(2)} s · tempo ${tempo.toFixed(2)}`);
    }
  }
  for(const [i,[frame,kind]] of ep.shots.flatMap(s=>s.sfx).entries()) addCue(frame,kind,i+9411);

  // Sparse original plucked bed, modulated by a short voice envelope.
  const scale=[261.626,329.628,392,440,523.251,392,329.628,293.665];
  let energy=0;
  for(let i=0;i<length;i++){
    const t=i/sampleRate;
    const beat=Math.floor(t/.487);
    const ph=t-beat*.487;
    const frequency=scale[(beat*3+Math.floor(beat/8))%scale.length];
    energy=Math.max(Math.abs(voice[i]),energy*.99975);
    const end=Math.min((length-i)/(2.2*sampleRate),1);
    const pluck=.041*Math.min(ph/.018,1)*Math.exp(-10*ph)*end/(1+6*energy);
    const bed=pluck*(tone(ph*frequency)+.29*tone(ph*frequency*2.003)+.11*tone(ph*frequency*3.012));
    left[i]+=voice[i]*.84+bed*.89;
    right[i]+=voice[i]*.84+bed*1.11;
  }
  const mixWav=join(temp,'mix.wav');
  await writeFile(mixWav,packWav([left,right]));
  const prepared=join(temp,'guide-mix.m4a');
  const targetLufs=-15;
  const filter=`loudnorm=I=${targetLufs}:TP=-1.3:LRA=9`;
  run('ffmpeg',['-v','error','-i',mixWav,'-af',`${filter},apad,atrim=duration=${ep.durationFrames/ep.fps},aresample=48000`,
    '-c:a','aac','-b:a','160k','-movflags','+faststart',prepared]);
  await mkdir(target,{recursive:true});
  const staged=resolve(target,`guide-mix.${process.pid}.partial.m4a`);
  try {
    await copyFile(prepared,staged);
    await rename(staged,resolve(target,'guide-mix.m4a'));
  } finally {await rm(staged,{force:true});}
  console.log(`Wrote ${target}/guide-mix.m4a from ${existing?'recorded narration':'local Indonesian eSpeak NG'} and ${ep.shots.flatMap(s=>s.sfx).length} original effects.`);
} finally {
  await rm(temp,{recursive:true,force:true});
}
