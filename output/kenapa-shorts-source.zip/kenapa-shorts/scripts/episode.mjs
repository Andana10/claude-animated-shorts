import {readFile, writeFile} from 'node:fs/promises';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

export const sfxTypes = ['charge', 'drop', 'flex', 'sweep', 'snap', 'click', 'unplug'];

export async function readEpisode(directory) {
  const ep = JSON.parse(await readFile(resolve(directory, 'episode.json'), 'utf8'));
  const require = (ok, problem) => {if (!ok) throw new Error(problem);};
  require(/^\d{3}$/.test(ep.id) && ep.title, 'Invalid episode ID or title');
  require(ep.fps === 30 && Number.isInteger(ep.durationFrames) && ep.durationFrames >= 1350 && ep.durationFrames <= 1800, 'Expected 45–60 seconds at 30 fps');
  require(ep.shots.length > 0, 'Episode has no shots');
  const ids = new Set();
  let cursor = 0;
  for (const shot of ep.shots) {
    require(shot.id && !ids.has(shot.id), `Duplicate or missing shot ID ${shot.id}`);
    ids.add(shot.id);
    require(shot.start === cursor && Number.isInteger(shot.end) && shot.end > shot.start, `Noncontiguous shot ${shot.id}`);
    cursor = shot.end;
    let cueEnd = shot.start;
    for (const cue of shot.cues) {
      require(Number.isInteger(cue.start) && Number.isInteger(cue.end) && cue.start >= cueEnd && cue.end <= shot.end && cue.end > cue.start && cue.text.trim(), `Invalid subtitle in ${shot.id}`);
      cueEnd = cue.end;
    }
    for (const [frame, kind] of shot.sfx) {
      require(Number.isInteger(frame) && frame >= shot.start && frame < shot.end && sfxTypes.includes(kind), `Invalid sound cue in ${shot.id}`);
    }
  }
  require(cursor === ep.durationFrames, 'Shot list does not cover the episode');
  return ep;
}

export function timecode(frame, fps, separator = ',') {
  const milliseconds = Math.round(frame * 1000 / fps);
  const hms = [Math.floor(milliseconds / 3600000), Math.floor(milliseconds / 60000) % 60, Math.floor(milliseconds / 1000) % 60].map(n => String(n).padStart(2,'0'));
  return hms.join(':') + separator + String(milliseconds % 1000).padStart(3,'0');
}

if (process.argv[1] && fileURLToPath(import.meta.url) === resolve(process.argv[1])) {
  const [mode, directory] = process.argv.slice(2);
  if (!['check', 'prepare'].includes(mode) || !directory) throw new Error('Usage: node scripts/episode.mjs check|prepare <episode-directory>');
  const ep = await readEpisode(directory);
  const tc = frame => timecode(frame, ep.fps);
  const cues = ep.shots.flatMap(shot => shot.cues);
  const files = {
    'subtitles.id.srt': cues.map(({start,end,text}, index) => `${index + 1}\n${tc(start)} --> ${tc(end)}\n${text}\n`).join('\n'),
    'narration.id.md': `# ${ep.title}\n\nNarasi Indonesia · ${ep.durationFrames / ep.fps} detik · ${ep.fps} fps\n\nNada penasaran dan santai. Beri jeda pendek setelah pertanyaan pembuka dan sebelum kalimat terakhir.\n\n` + ep.shots.map(s => `## ${tc(s.start)} · ${s.heading}\n\n${s.cues.map(c=>c.text).join(' ')}\n`).join('\n'),
    'storyboard.md': `# Storyboard · ${ep.title}\n\nDurasi ${ep.durationFrames / ep.fps} detik. Frame akhir tiap shot bersifat eksklusif.\n\n| Shot | Waktu | Frame | Aksi dan kamera | SFX (frame) |\n| --- | --- | --- | --- | --- | --- |\n` + ep.shots.map((s,i) => `| ${i+1} · ${s.heading} | ${tc(s.start)}–${tc(s.end)} | ${s.start}–${s.end} | ${s.direction} | ${s.sfx.map(([f,k])=>`${k} ${f}`).join(', ')} |\n`).join('')
  };
  for (const [name, body] of Object.entries(files)) {
    const path = resolve(directory, name);
    if (mode === 'prepare') await writeFile(path, body);
    else if (await readFile(path,'utf8') !== body) throw new Error(`Regenerate ${path} with prepare`);
  }
  console.log(`${ep.title} · ${ep.shots.length} shots · ${cues.length} cues · ${ep.durationFrames} frames`);
}
