import {rename,mkdir,access,rm} from 'node:fs/promises';
import {dirname,resolve} from 'node:path';
import {availableParallelism} from 'node:os';
import {bundle} from '@remotion/bundler';
import {openBrowser,renderMedia,renderStill,selectComposition} from '@remotion/renderer';
import {browserOptions} from './platform.mjs';
import {readEpisode} from './episode.mjs';

const [mode, destination, samples] = process.argv.slice(2);
const episode = process.env.EPISODE || '001';
if(!/^\d{3}$/.test(episode)) throw new Error('EPISODE must be a three-digit ID');
const configurations = {
  smoke:{id:'Smoke', file:'renders/smoke.mp4', threads:1,crf:25},
  stills:{id:`EP${episode}-Preview`,file:`renders/episode-${episode}-stills`,threads:1,crf:23},
  preview:{id:`EP${episode}-Preview`,file:`renders/episode-${episode}-preview.mp4`,threads:Math.min(2,availableParallelism()),crf:21},
  final:{id:`EP${episode}-Final`,file:`renders/episode-${episode}-final.mp4`,threads:Math.min(2,availableParallelism()),crf:17},
};
const config = configurations[mode];
if(!config) throw new Error('Usage: node scripts/render.mjs smoke|stills|preview|final [destination] [comma-separated still frames]');
const output = resolve(destination || config.file);
const dir = mode==='stills'?output:dirname(output);
await mkdir(dir,{recursive:true});
const profile = process.env.RENDER_PROFILE || (mode==='final'?'cinema':'software');
if(!['software','cinema'].includes(profile)) throw new Error('RENDER_PROFILE must be software or cinema');
const concurrency = Number(process.env.RENDER_CONCURRENCY ?? config.threads);
if(!Number.isInteger(concurrency) || concurrency<1) throw new Error('RENDER_CONCURRENCY must be a positive integer');
const audioPath = `episode-${episode}/guide-mix.m4a`;
const hasAudio = await access(resolve('public',audioPath)).then(()=>true,()=>false);
const audio = !process.env.SILENT && mode!=='smoke' && hasAudio ? audioPath : null;
const pixelRatio=Number(process.env.RENDER_PIXEL_RATIO ?? 1);
if(!Number.isFinite(pixelRatio) || pixelRatio<.5 || pixelRatio>1) throw new Error('RENDER_PIXEL_RATIO must be between 0.5 and 1');
const inputProps = {profile,audio,captions:process.env.CAPTIONS!=='off',pixelRatio};
const settings = await browserOptions();
console.log(`${config.id} · ${profile} @ ${pixelRatio}× WebGL · ${settings.chromiumOptions.gl} · ${settings.browserExecutable ?? 'Remotion Headless Shell'} · ${audio?'guide audio':'silent'}`);
const serveUrl = await bundle({entryPoint:resolve('src/index.ts'),onProgress:() => {}});
let browser;
try {
  browser=await openBrowser('chrome',settings);
  const renderOptions = {serveUrl,inputProps,puppeteerInstance:browser,timeoutInMilliseconds:120000,...settings,
    onBrowserLog:({type,text})=>{if(type==='error') console.error(`Chromium: ${text}`);}};
  const composition = await selectComposition({...renderOptions,id:config.id});
  async function renderStills(frames,directory) {
    await mkdir(directory,{recursive:true});
    for (const frame of frames) {
      if (!Number.isInteger(frame) || frame<0 || frame>=composition.durationInFrames) throw new Error(`Bad still frame ${frame}`);
      const image = resolve(directory,`${String(frame).padStart(4,'0')}.jpg`);
      await renderStill({...renderOptions,composition,frame,output:image,imageFormat:'jpeg',jpegQuality:90});
      console.log(image);
    }
  }
  if(mode==='stills') {
    const frames = samples ? samples.split(',').map(Number) : (await readEpisode(`episodes/${episode}`)).shots
      .map(shot=>Math.floor((shot.start+shot.end)/2));
    await renderStills(frames,dir);
  } else {
    if(process.env.REVIEW_FRAMES) await renderStills(process.env.REVIEW_FRAMES.split(',').map(Number),resolve(dir,'review-stills'));
    const tempVideo = `${output}.${process.pid}.partial.mp4`;
    try {
      const frameRange=process.env.RENDER_FRAMES?.split(',').map(Number);
      if(frameRange && (frameRange.length!==2 || frameRange.some(f=>!Number.isInteger(f)) ||
        frameRange[0]<0 || frameRange[1]<frameRange[0] || frameRange[1]>=composition.durationInFrames)) throw new Error('RENDER_FRAMES must be two inclusive in-range frame numbers');
      let next=0;
      await renderMedia({...renderOptions,composition,codec:'h264',pixelFormat:'yuv420p',imageFormat:'jpeg',
        crf:config.crf,jpegQuality:86,sampleRate:48000,muted:!audio,outputLocation:tempVideo,
        concurrency,frameRange,
        onProgress:p=>{
          if(p.progress>=next || p.progress===1) {
            console.log(`${Math.round(p.progress*100)}% · ${p.renderedFrames} frames · ${p.encodedFrames} encoded`);
            next=p.progress+.05;
          }
        },
      });
      await rename(tempVideo,output);
      console.log(output);
    } finally {
      await rm(tempVideo,{force:true});
    }
  }
} finally {
  if(browser) await browser.close({silent:true});
  await rm(serveUrl,{recursive:true,force:true});
}
