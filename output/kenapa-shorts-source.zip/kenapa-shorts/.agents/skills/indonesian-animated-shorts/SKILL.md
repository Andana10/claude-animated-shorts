---
name: indonesian-animated-shorts
description: Produce and verify original 45–60 second Indonesian everyday-science explainers in a cinematic 2.5D Remotion and Three.js workflow. Use for episodes of Kenapa Hal Sehari-hari Bisa Begitu? or for updating their scripts, shots, audio, captions, and renders.
---

# Indonesian animated shorts

Read the project [README](../../../README.md), [AGENTS.md](../../../AGENTS.md), and [upstream audit](../../../docs/upstream-audit.md). Open the current episode JSON and check for prior scenes or edits.

## Script and storyboard

- Verify the mechanism with primary sources. In `fact-check.md`, connect each claim to its source and describe any schematic simplification.
- Open immediately on a recognizable failure or surprise. Move through a physical cause, a macro reveal, a practical action and a visual callback. Speak in conversational Indonesian suited to ages 17–45. Leave enough time to read each complete caption.
- Introduce a product only when it solves a specific problem in the story. Treat it as optional when a free habit works. Verify objective claims. When a real affiliate link is supplied, disclose it in the publication copy in clear Indonesian. Keep offer copy free of invented results, prices, discounts, or testimonials.
- Fill `episodes/NNN/episode.json` with camera direction, half-open shot and cue ranges, and frame-timed sounds. Generate the narration guide, shot list and SRT with `node scripts/episode.mjs prepare episodes/NNN`.

## Build the picture

- Use the original Kiko canvas billboard with plum ink, scene lighting, and a contact shadow. Build dimensioned 3D props, use warm directional and cool fill lighting, and preserve foreground/background separation. Pose silhouettes so eyes, hands, the prop and the problem can be read at phone size.
- Direct camera movement along frame-keyed paths with controlled glide and a gentle drift. Stage macro close-ups at the relevant contact point and hold focus on the subject. Layer geometric ink in preview and keep screen-space normal/depth ink ahead of lens blur in the cinema profile.
- Create changes the viewer can see even when muted. Use the frame clock for motions, reveal levels, facial poses, cuts, and phase changes. Keep labels concise and place syllable-timed or phrase-timed Indonesian subtitles within the lower safe area.
- Record a timed Indonesian track or use the local eSpeak NG guide. Synchronize the sound events from the same JSON and regenerate the mix after timing edits. A silent captioned render and a separate script work without TTS.

## Verify and finish

1. Run `npm ci`, `npm run check`, `npm run doctor` and `npm run smoke` on a fresh runner. On Linux without a GPU, start with `swangle` and verify the WebGL2 probe.
2. Render selected frames at 540×960. Inspect subject visibility, cable or prop geometry, transition clearances, subtitle safe areas, cutaway readability, and the macro focus plane. Fix the source and inspect changed frames.
3. Render the complete preview. Run FFprobe, the black/freeze checks and contact-sheet generation via `scripts/qa.mjs`. Review motion and cue points in the MP4. Use the 1080×1920 composition for final export and verify the resulting file.
4. Deliver the exact artifacts produced, the source and upstream notices, and the command for a clean rebuild. Report exact rendering errors for any unavailable output.

Use [Episode 001](../../../episodes/001/storyboard.md) as a production reference. The recurring host, workspace, teaching mechanism, and sound palette can evolve as the topic changes.
