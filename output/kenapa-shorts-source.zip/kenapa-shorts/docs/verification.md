# Render verification

The Linux run used Node 24.22.3, Chromium 156.0.8078.79, Three.js r180, Remotion 4.0.546, and FFmpeg 7.1.5. A clean `npm ci` install and `npm run check` passed. npm audit reported zero known vulnerabilities in the locked tree at the time of the check.

- Chromium ANGLE reported a SwiftShader renderer. The WebGL2 probe read back RGBA 64, 128, 191, 255.
- The direct FFmpeg test encoded 12 H.264 frames at 30 fps. The Remotion smoke test encoded 24 animated Three.js frames at 270×480 and 30 fps.
- An episode cinema test rendered and decoded 12 H.264 frames at 1080×1920 and 30 fps, with 48 kHz stereo AAC. The opening scene and strand-fracture close-up were inspected at final resolution.
- Still reviews found a cable connector overlapping the phone screen and a grip silhouette displaced from the housing. Both were corrected, then checked again along with the strain markers and the damaged cable.
- FFprobe read all 21 SubRip cues. The local Indonesian guide mix measured −15.1 LUFS integrated and −1.3 dB true peak before Remotion encoding.

Reproduce the 1080×1920 cinema test from the packaged project.

```sh
RENDER_FRAMES=716,727 RENDER_CONCURRENCY=1 npm run final:001 -- renders/1080p-excerpt.mp4
```

## Complete preview

Rendered 1,620 frames in Chromium with SwiftShader. FFprobe verified a 54-second H.264 picture at 540×960 and 30 fps with stereo AAC at 48 kHz. The encoded audio measured −15.1 LUFS integrated and −1.3 dB true peak. The full decode passed black and freeze detection. Visual review covered all ten shots and the connector removal and cable replacement actions. [Technical report](preview-verification.json)

The delivered cloud preview used a 297×528 WebGL buffer, upsampled into the 540×960 composition. The graphics and subtitles use the full composition size. Reproduce this preview on a GPU-less Linux system.

```sh
RENDER_PIXEL_RATIO=.55 RENDER_CONCURRENCY=1 npm run preview:001
npm run qa:001
```
