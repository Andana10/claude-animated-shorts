# Upstream audit

Reviewed `README.md`, `SKILL.md`, `references/STYLE_BIBLE.md`, the bridge world, cast, camera and post templates, the example script and sandbox entry, and the sound and inspection templates at commit `e3b817b6afc6cd413466d43f11ba31209e034bbf`. The original is a Claude Code skill and a bridge episode template that expects an existing Remotion project, external world assets and audio, and machine-specific paths. Its MIT license covers the code and docs. The repository identifies the supplied reference imagery as style-study material. [Pinned upstream](https://github.com/mromidev/claude-animated-shorts/tree/e3b817b6afc6cd413466d43f11ba31209e034bbf)

| Upstream technique | Adaptation |
| --- | --- |
| Remotion clock and Three.js 3D world | Locked project, real 540×960 and 1080×1920 compositions, persistent scene, deterministic pose per frame. |
| Canvas 2D characters on lit billboards | Original Kiko rig with a cap and apron, drawn with Canvas 2D paths, local expressions, gestures, face motion, blinks and contact shadows. |
| Painted environment, warm key, cool shade | Procedural workbench with window scenery and material contrast. The separate macro stage uses cool depth and copper highlights. |
| Timeline shot plan, keyed cameras, cut/flash cues | Validated shot manifest and timecoded captions, eased camera offsets, same-axis cutaway and return-to-desk cuts, brief color wipes and impact kicks. |
| Normal/depth ink before depth-of-field, restrained bloom and grade | Ported MIT `ink.ts`, `lensblur.ts` and `grade.ts`. Cinema uses the complete post chain. Preview uses geometric creases and a nine-tap shader derived from the upstream lens effect. Full and preview render the same geometry at native output resolution. |
| Synthesized sound, timed placement, dialogue ducking | Original procedural sounds and plucked underscore, one caption-aligned local narration track and a frame-indexed effects list. |
| Frame inspection, loudness and media checks | Linux browser/FFmpeg probe, Remotion smoke clip, deterministic stills, FFprobe stream checks and automated black/freeze flags, plus manual verification of contact sheets. |
| Claude orchestration, 2K/English default, desktop-specific figures | Repository-scoped Codex skill and AGENTS instructions, native Indonesian subtitles and 1080×1920 output, browser discovery and software WebGL. |

The derivative includes the upstream license and reusable post code. Kiko, the cable choreography, textures, and soundtrack were made for this series. Barlow Condensed and DM Sans are distributed through pinned Fontsource packages under the SIL Open Font License.
