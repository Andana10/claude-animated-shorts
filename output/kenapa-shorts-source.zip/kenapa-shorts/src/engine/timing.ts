import {MathUtils, PerspectiveCamera, Vector3} from 'three';

export type Vec3 = [number, number, number];
export type CameraPose = {eye: Vec3; target: Vec3; fov: number; roll?: number};
export type CameraKey = CameraPose & {at: number};

export const clamp = (v: number) => MathUtils.clamp(v, 0, 1);
export const smooth = (v: number) => {
  const x = clamp(v);
  return x * x * (3 - 2 * x);
};
export const lerp = MathUtils.lerp;
export const ramp = (frame: number, start: number, end: number) => smooth((frame - start) / (end - start));
export const envelope = (frame: number, start: number, duration = 12) =>
  frame < start || frame >= start + duration ? 0 : 1 - (frame - start) / duration;

const mix3 = (a: Vec3, b: Vec3, t: number): Vec3 =>
  [lerp(a[0], b[0], t), lerp(a[1], b[1], t), lerp(a[2], b[2], t)];

export function cameraAt(keys: readonly CameraKey[], progress: number): CameraPose {
  const next = keys.findIndex(k => k.at >= progress);
  if (next === 0) return keys[0];
  if (next < 0) return keys[keys.length - 1];
  const a = keys[next - 1];
  const b = keys[next];
  const t = lerp((progress - a.at) / (b.at - a.at), smooth((progress - a.at) / (b.at - a.at)), 0.68);
  return {
    eye: mix3(a.eye, b.eye, t), target: mix3(a.target, b.target, t),
    fov: lerp(a.fov, b.fov, t), roll: lerp(a.roll ?? 0, b.roll ?? 0, t),
  };
}

export function aimCamera(camera: PerspectiveCamera, pose: CameraPose, kick = 0) {
  camera.position.set(...pose.eye);
  camera.lookAt(...pose.target);
  camera.rotateZ((pose.roll ?? 0) + kick);
  if (camera.fov !== pose.fov) {
    camera.fov = pose.fov;
    camera.updateProjectionMatrix();
  }
  camera.updateMatrixWorld(true);
  return new Vector3(...pose.target).sub(camera.position).dot(camera.getWorldDirection(new Vector3()));
}
