import {AbsoluteFill,useCurrentFrame,useVideoConfig} from 'remotion';
import type {CSSProperties,ReactNode} from 'react';

export type Cue = {start:number;end:number;text:string};
export const activeCue = (cues: readonly Cue[], frame: number) => cues.find(c=>frame>=c.start && frame<c.end);
export const displayFont = '"Barlow Condensed", sans-serif';
export const bodyFont = '"DM Sans", sans-serif';
export const safeArea = {left:74,right:114};

export function DesignSpace({children}: {children:ReactNode}) {
  const {width} = useVideoConfig();
  return <AbsoluteFill style={{pointerEvents:'none',overflow:'hidden'}}>
    <div style={{width:1080,height:1920,position:'relative',flexShrink:0,transformOrigin:'top left',transform:`scale(${width/1080})`,fontFamily:bodyFont}}>
      {children}
    </div>
  </AbsoluteFill>;
}

const backdrop: CSSProperties = {
  position:'absolute',left:safeArea.left,right:safeArea.right,bottom:199,
  color:'#fff6e4',textAlign:'center',fontFamily:bodyFont,fontSize:48,letterSpacing:-.8,
  fontWeight:700,lineHeight:1.17,display:'flex',justifyContent:'center',
};

export function Captions({cues}: {cues: readonly Cue[]}) {
  const cue = activeCue(cues,useCurrentFrame());
  if (!cue) return null;
  return <div style={backdrop}><span style={{
    background:'rgba(18,24,39,.91)',padding:'16px 27px 18px',borderRadius:19,
    borderBottom:'3px solid #78b9aa',maxWidth:850,textWrap:'balance',
  }}>{cue.text}</span></div>;
}
