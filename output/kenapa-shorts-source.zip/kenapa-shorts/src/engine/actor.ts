import * as T from 'three';
import {NOINK} from './post/ink';
import {groundShadow, place} from './props';

export type Expression = 'curious' | 'worried' | 'idea' | 'proud' | 'wink';
const plum = '#281d34';
const skin = '#f8bd81';
const cream = '#fff3d8';

function path(g: CanvasRenderingContext2D, d: string, fill: string | null, strokeWidth = 6, stroke = plum) {
  const p = new Path2D(d);
  if (fill) {
    g.fillStyle = fill;
    g.fill(p);
  }
  if (strokeWidth) {
    g.lineWidth = strokeWidth;
    g.strokeStyle = stroke;
    g.stroke(p);
  }
}
function oval(g: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, fill: string, outline = 0) {
  g.beginPath();
  g.ellipse(x,y,rx,ry,0,0,2*Math.PI);
  g.fillStyle = fill;
  g.fill();
  if (outline) {
    g.lineWidth = outline;
    g.strokeStyle = plum;
    g.stroke();
  }
}

function drawKiko(g: CanvasRenderingContext2D, expression: Expression, blink: boolean, pose: number, gaze: number, talk: number) {
  g.clearRect(0,0,420,520);
  g.lineJoin = 'round';
  g.lineCap = 'round';
  g.save();
  g.translate(210,470);
  g.rotate(pose * .085);
  g.translate(-210,-470);

  // Flat ink limbs underscored by a cropped carpenter's apron.
  path(g,'M172 396 Q173 426 158 472 M235 395 Q240 429 247 471',null, 15);
  path(g,'M160 466 Q146 466 129 486 Q126 496 155 495 L179 495 Q193 491 184 480 Q173 464 160 466Z','#e76d58', 6);
  path(g,'M247 465 Q261 466 281 482 Q291 494 263 495 L236 495 Q225 490 232 478 Q239 469 247 465Z','#e76d58', 6);
  path(g,'M150 296 Q127 321 105 350',null,16);
  path(g,'M150 296 Q127 321 105 350',null,8,'#f4b57e');
  const handY = 236 + 104 * (1 - pose);
  const handX = 313 + 28 * pose;
  const arm = `M248 300 Q284 326 ${handX} ${handY}`;
  path(g,arm,null,17);
  path(g,arm,null,8,'#f4b57e');
  oval(g,handX,handY,16,14,skin,5);
  oval(g,100,354,14,13,skin,5);
  path(g,'M153 275 Q179 257 228 261 Q252 267 256 296 L253 389 Q235 415 152 404 Q132 389 143 324Z','#f0b849',7);
  path(g,'M162 279 L181 321 M234 276 L220 320',null,10,'#6e4447');
  path(g,'M178 312 L222 312 L233 376 Q211 396 160 382Z','#34978c',6);
  path(g,'M177 350 Q204 355 220 351 L216 372 Q196 379 180 371Z','#6bc4a3',3);

  path(g,'M112 166 Q94 153 89 183 Q88 207 116 215 L128 202Z',skin,7);
  path(g,'M104 163 Q96 106 136 76 Q172 47 223 56 Q278 65 291 119 Q303 157 284 206 Q272 259 222 271 Q167 282 137 253 Q105 223 104 163Z',skin,8);
  path(g,'M104 176 Q93 136 106 114 Q120 87 151 83 Q175 75 181 59 Q220 66 241 86 Q265 80 288 104 Q305 127 291 164 Q268 148 250 133 Q224 146 207 123 Q180 154 143 144 L129 178Z','#39304c',6);
  path(g,'M108 118 Q110 64 148 50 Q199 28 235 57 Q253 73 257 102 Q193 90 108 118Z','#72b9aa',7);
  path(g,'M135 70 Q168 44 205 54',null,5,'#b9ddbf');
  path(g,'M107 113 Q177 91 245 99 Q286 100 305 112 Q320 125 289 131 Q251 133 223 114 Q165 108 107 125Z','#f6c558',7);

  const squint = blink || expression === 'wink';
  path(g,expression === 'worried' ? 'M148 169 Q159 156 177 160 M223 155 Q238 153 250 166' : 'M150 160 Q161 153 173 158 M223 158 Q235 147 248 155',null,5);
  for (const [i,x] of [166,235].entries()) {
    if (blink || (i === 1 && squint)) path(g,`M${x-9} 182 q9 7 18 0`,null,6);
    else {
      oval(g,x,182,15,20,cream,4);
      oval(g,x + 5*gaze,185,6,11,plum);
    }
  }
  path(g,'M203 184 Q198 197 209 198',null,4,'#a0564a');
  if (talk > .3) {
    oval(g,207,222,19,7 + talk * 7,plum);
    path(g,'M194 222 Q208 218 219 223',null,3,'#fa8a76');
  } else if (expression === 'worried') path(g,'M190 224 Q207 210 224 222',null,5);
  else if (expression === 'curious') oval(g,211,220,10,11,plum);
  else path(g,'M185 218 Q204 237 229 213 Q223 244 201 238Z',cream,5);
  g.restore();
}

export class Kiko {
  readonly card: T.Mesh<T.PlaneGeometry, T.MeshLambertMaterial>;
  readonly shadow: ReturnType<typeof groundShadow>;
  private readonly context: CanvasRenderingContext2D;
  private readonly texture: T.CanvasTexture;
  private last = '';

  constructor(parent: T.Object3D) {
    const canvas = document.createElement('canvas');
    canvas.width = 420;
    canvas.height = 520;
    this.context = canvas.getContext('2d')!;
    this.texture = new T.CanvasTexture(canvas);
    this.texture.colorSpace = T.SRGBColorSpace;
    this.card = place(parent,new T.Mesh(new T.PlaneGeometry(2.05,2.54),new T.MeshLambertMaterial({
      color: '#fff3e0', map: this.texture, alphaTest: .4, side: T.DoubleSide,
    })));
    this.card.layers.set(NOINK);
    this.shadow = groundShadow(parent,1.65,.9,0,0,.44);
  }

  pose(camera: T.Camera, frame: number, expression: Expression, point: number, speak: boolean, x: number, z: number, scale = 1) {
    const blink = (frame + 21) % 49 < 3;
    const mouth = speak ? Math.round((.5 + .5 * Math.sin(frame * .87)) * 4) / 4 : 0;
    const wave = Math.round(point * 30) / 30;
    const key = `${expression}|${blink}|${wave}|${mouth}`;
    if (key !== this.last) {
      drawKiko(this.context,expression,blink,wave,.65,mouth);
      this.texture.needsUpdate = true;
      this.last = key;
    }
    this.card.scale.setScalar(scale);
    this.card.position.set(x,1.28 * scale + .023 * Math.sin(frame * .15),z);
    this.card.quaternion.copy(camera.quaternion);
    this.shadow.scale.setScalar(scale);
    this.shadow.position.x = x;
    this.shadow.position.z = z;
  }
}
