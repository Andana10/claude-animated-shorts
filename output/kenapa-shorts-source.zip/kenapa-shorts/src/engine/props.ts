import * as T from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {NOINK} from './post/ink';

export const ink = '#202437';
export const standard = (color: T.ColorRepresentation, roughness = .7, metalness = 0) =>
  new T.MeshStandardMaterial({color, roughness, metalness});
export const flat = (color: T.ColorRepresentation) => new T.MeshBasicMaterial({color});

export function place<O extends T.Object3D>(parent: T.Object3D, item: O, x = 0, y = 0, z = 0) {
  item.position.set(x, y, z);
  parent.add(item);
  return item;
}

export function box(parent: T.Object3D, dims: [number, number, number], material: T.Material,
  x = 0, y = 0, z = 0, radius = .04) {
  return place(parent, new T.Mesh(new RoundedBoxGeometry(...dims, 2, radius), material), x, y, z);
}

export function hardEdges(mesh: T.Mesh, opacity = .5) {
  const edges = new T.LineSegments(new T.EdgesGeometry(mesh.geometry, 32), new T.LineBasicMaterial({
    color: ink, transparent: true, opacity,
  }));
  edges.layers.set(NOINK);
  mesh.add(edges);
}

export function paintTexture(width: number, height: number, draw: (g: CanvasRenderingContext2D) => void) {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d')!;
  draw(context);
  const texture = new T.CanvasTexture(canvas);
  texture.colorSpace = T.SRGBColorSpace;
  texture.anisotropy = 4;
  return texture;
}

export function groundShadow(parent: T.Object3D, sx: number, sz: number, x: number, z: number, strength = .45, y = .013) {
  const map = paintTexture(96, 96, g => {
    const fade = g.createRadialGradient(48,48,0,48,48,48);
    fade.addColorStop(0,'#1b1a32');
    fade.addColorStop(.42,'#1b1a32aa');
    fade.addColorStop(1,'#1b1a3200');
    g.fillStyle = fade;
    g.fillRect(0,0,96,96);
  });
  const mat = new T.MeshBasicMaterial({map, transparent: true, depthWrite: false, opacity: strength, polygonOffset: true, polygonOffsetFactor: -1});
  const blob = place(parent, new T.Mesh(new T.PlaneGeometry(sx, sz), mat), x, y, z);
  blob.layers.set(NOINK);
  blob.rotation.x = -Math.PI / 2;
  return blob;
}

export type TubePoint = (u: number, point: T.Vector3) => T.Vector3;

/** Reuse a tube’s buffers as its centerline, gap and cross-section change. */
export class FlexTube extends T.Mesh<T.BufferGeometry, T.Material> {
  private readonly vertices: T.BufferAttribute;
  private readonly normals: T.BufferAttribute;
  private readonly p = new T.Vector3();
  private readonly q = new T.Vector3();
  private readonly normal = new T.Vector3();
  constructor(material: T.Material, private readonly steps = 36, private readonly rings = 10) {
    const geometry = new T.BufferGeometry();
    const count = (steps + 1) * (rings + 1);
    const vertices = new T.BufferAttribute(new Float32Array(count * 3), 3).setUsage(T.DynamicDrawUsage);
    const normals = new T.BufferAttribute(new Float32Array(count * 3), 3).setUsage(T.DynamicDrawUsage);
    const uv = new T.BufferAttribute(new Float32Array(count * 2), 2);
    const indices: number[] = [];
    for (let i = 0; i <= steps; i++) {
      for (let j = 0; j <= rings; j++) {
        const k = i * (rings + 1) + j;
        uv.setXY(k, i / steps, j / rings);
        if (i < steps && j < rings) indices.push(k, k + 1, k + rings + 1, k + 1, k + rings + 2, k + rings + 1);
      }
    }
    geometry.setAttribute('position', vertices);
    geometry.setAttribute('normal', normals);
    geometry.setAttribute('uv', uv);
    geometry.setIndex(indices);
    super(geometry, material);
    this.vertices = vertices;
    this.normals = normals;
    this.frustumCulled = false;
  }

  pose(point: TubePoint, radius: number, start = 0, end = 1, arcStart = 0, arcEnd = Math.PI * 2) {
    for (let i = 0; i <= this.steps; i++) {
      const u = T.MathUtils.lerp(start, end, i / this.steps);
      point(u, this.p);
      point(u + .0005, this.q).sub(this.p).normalize();
      this.normal.set(-this.q.y, this.q.x, 0).normalize();
      for (let j = 0; j <= this.rings; j++) {
        const angle = T.MathUtils.lerp(arcStart, arcEnd, j / this.rings);
        const nx = this.normal.x * Math.cos(angle);
        const ny = this.normal.y * Math.cos(angle);
        const nz = Math.sin(angle);
        const k = i * (this.rings + 1) + j;
        this.vertices.setXYZ(k, this.p.x + nx * radius, this.p.y + ny * radius, this.p.z + nz * radius);
        this.normals.setXYZ(k, nx, ny, nz);
      }
    }
    this.vertices.needsUpdate = true;
    this.normals.needsUpdate = true;
  }
}

export function disposeWorld(root: T.Object3D) {
  const geometries = new Set<T.BufferGeometry>();
  const materials = new Set<T.Material>();
  const textures = new Set<T.Texture>();
  root.traverse(node => {
    const mesh = node as T.Mesh;
    if (!mesh.geometry || !mesh.material) return;
    geometries.add(mesh.geometry);
    for (const material of Array.isArray(mesh.material) ? mesh.material : [mesh.material]) {
      materials.add(material);
      for (const value of Object.values(material)) {
        if (value instanceof T.Texture) textures.add(value);
      }
    }
  });
  for (const texture of textures) texture.dispose();
  for (const material of materials) material.dispose();
  for (const geometry of geometries) geometry.dispose();
}
