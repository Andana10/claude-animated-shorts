import {ThreeCanvas} from '@remotion/three';
import {useFrame,useThree} from '@react-three/fiber';
import {BloomEffect,EffectComposer,EffectPass,RenderPass,ToneMappingEffect,ToneMappingMode} from 'postprocessing';
import {useEffect,useMemo} from 'react';
import {useCurrentFrame,useVideoConfig} from 'remotion';
import {HalfFloatType,NoToneMapping,PerspectiveCamera,Scene,type Group} from 'three';
import {disposeWorld} from './props';
import {GRADE_GOLDEN2, GradeEffect} from './post/grade';
import {InkPass,NOINK,noInkFallback} from './post/ink';
import {LensBlur,LensBlurEffect} from './post/lensblur';

export type Profile = 'software' | 'cinema';
type World = {
  root: Group;
  update(scene: Scene, camera: PerspectiveCamera, frame: number): {focus:number; blur:number};
};

function SceneView({makeWorld,profile}: {makeWorld:() => World; profile:Profile}) {
  const frame = useCurrentFrame();
  const {scene, camera, gl, size} = useThree();
  const cam = camera as PerspectiveCamera;
  const world = useMemo(makeWorld,[makeWorld]);
  const post = useMemo(() => {
    cam.layers.enable(NOINK);
    noInkFallback(world.root);
    const composer = new EffectComposer(gl,{frameBufferType:HalfFloatType,multisampling:0});
    composer.addPass(new RenderPass(scene,cam));
    const full = profile === 'cinema';
    if(full) {
      composer.addPass(new InkPass(scene,cam,{
        color:'#23263a',strength:.72,widthNear:3.8,widthFar:2.35,distNear:2,distFar:12,
        fadeNear:18,fadeFar:38,creaseScale:.58,
      }));
    }
    const lens = full ? new LensBlur({maxCoC:17}) : new LensBlurEffect({
      maxCoC:17,stage:{taps:9,spread:1,nearTaps:0,rot:.4},
    });
    if(lens instanceof LensBlur) {
      composer.addPass(new EffectPass(cam,lens.pre));
      composer.addPass(new EffectPass(cam,lens.main));
    } else composer.addPass(new EffectPass(cam,lens));
    const tone = new ToneMappingEffect({mode:ToneMappingMode.NEUTRAL});
    const grade = new GradeEffect(GRADE_GOLDEN2,.36);
    if(full) {
      const bloom = new BloomEffect({intensity:.31,luminanceThreshold:1.13,mipmapBlur:true,levels:4,radius:.42});
      composer.addPass(new EffectPass(cam,bloom,tone,grade));
    } else composer.addPass(new EffectPass(cam,tone,grade));
    return {composer,lens};
  },[cam,gl,scene,world,profile]);

  useEffect(() => {
    post.composer.setSize(size.width,size.height,false);
  },[post,size.width,size.height]);
  useEffect(() => () => post.composer.dispose(),[post]);
  useEffect(() => () => disposeWorld(world.root),[world]);

  const {focus,blur} = world.update(scene,cam,frame);
  post.lens.focus = focus;
  post.lens.cInf = blur;
  useFrame(() => post.composer.render(0),1);
  return <primitive object={world.root} dispose={null}/>;
}

export function Stage({makeWorld,profile,pixelRatio=1}: {makeWorld:() => World; profile:Profile; pixelRatio?:number}) {
  const {width,height} = useVideoConfig();
  return (
    <ThreeCanvas width={width} height={height} dpr={pixelRatio}
      gl={{antialias:false,stencil:false,alpha:false,powerPreference:'high-performance',toneMapping:NoToneMapping}}
      camera={{fov:35,near:.07,far:70}}>
      <SceneView makeWorld={makeWorld} profile={profile}/>
    </ThreeCanvas>
  );
}
