import '@fontsource/barlow-condensed/latin-800.css';
import '@fontsource/dm-sans/latin-600.css';
import '@fontsource/dm-sans/latin-700.css';
import {AbsoluteFill,Audio,staticFile,useCurrentFrame,useDelayRender} from 'remotion';
import {useEffect,useState} from 'react';
import {Captions,DesignSpace,displayFont,safeArea} from '../../engine/Captions';
import {Stage,type Profile} from '../../engine/Stage';
import {clamp,envelope,ramp} from '../../engine/timing';
import {EpisodeWorld} from './world';
import data from '../../../episodes/001/episode.json';

export type EpisodeProps = {profile?: Profile; audio?: string | null; captions?: boolean; pixelRatio?:number};
const world = () => new EpisodeWorld();
const cues = data.shots.flatMap(s=>s.cues);
const chapterColor = ['#ffcc77','#ffcc77','#ffc570','#ffb685','#f7ad83','#ffcf95','#a3e6cc','#a3e6cc','#a3e6cc','#c5f2bd'];
const wipes = [150,462,807,969,1128,1287,1443];
const palette = {ivory:'#fff2d7', shadow:'#161b2a'};

function useEpisodeFonts() {
  const {delayRender,continueRender,cancelRender} = useDelayRender();
  const [handle] = useState(() => delayRender('Load locally bundled episode fonts'));
  useEffect(() => {
    Promise.all([
      document.fonts.load('800 120px "Barlow Condensed"'),
      document.fonts.load('700 48px "DM Sans"'),
      document.fonts.load('600 30px "DM Sans"'),
    ]).then(()=>continueRender(handle),cancelRender);
  },[cancelRender,continueRender,handle]);
}

function Tag({label,value,left,right,top,color,opacity}: {
  label:string;value?:string;left?:number;right?:number;top:number;color:string;opacity:number;
}) {
  return <div style={{position:'absolute',left,right,top,opacity,display:'flex',gap:13,alignItems:'flex-start',color:palette.ivory,
    transform:`translateY(${(1-opacity)*19}px)`}}>
    <span style={{width:27,height:2,marginTop:15,background:color,boxShadow:'0 0 12px #131724'}}/>
    <div style={{background:'#182337e8',border:'1px solid #d5d4b83b',padding:'10px 14px 11px',borderRadius:7}}>
      <div style={{fontSize:24,fontWeight:700,letterSpacing:1.6,lineHeight:1.02,color}}>{label}</div>
      {value && <div style={{fontSize:23,fontWeight:600,marginTop:6}}>{value}</div>}
    </div>
  </div>;
}

function Graphics({showCaptions}: {showCaptions:boolean}) {
  const frame = useCurrentFrame();
  const index = Math.max(0,data.shots.findIndex(s=>frame < s.end));
  const shot = data.shots[index];
  const f = frame-shot.start;
  const entrance = ramp(f,0,11);
  const fade = wipes.reduce((acc,start)=>Math.max(acc,envelope(frame,start-2,11)),0);
  const accent = chapterColor[index];
  const heading = shot.id==='hook' ? <>KENAPA KABEL<br/>RUSAK <span style={{color:accent}}>DI SINI?</span></> : shot.heading.toUpperCase();
  return <DesignSpace>
    <AbsoluteFill style={{background:'linear-gradient(180deg, #182333df 0%, #182333b0 9%, #17233544 22%, transparent 38%, transparent 73%, #18233883 100%)'}}/>
    <div style={{position:'absolute',left:safeArea.left,right:safeArea.right,top:85,color:palette.ivory}}>
      <div style={{display:'flex',alignItems:'center',gap:19,fontWeight:700}}>
        <div style={{width:55,height:55,background:'#f7be70',color:'#20293e',borderRadius:'14px 14px 14px 2px',fontFamily:displayFont,fontSize:37,textAlign:'center',lineHeight:'51px'}}>K?</div>
        <span style={{fontSize:26,letterSpacing:1.4}}>KENAPA HAL SEHARI-HARI</span>
      </div>
      <div style={{height:2,background:'#f9edc65e',marginTop:20}}>
        <div style={{height:2,width:`${100*(frame+1)/data.durationFrames}%`,background:accent}}/>
      </div>
      <div style={{marginTop:26,opacity:.37+.63*entrance,transform:`translateY(${(1-entrance)*19}px)`}}>
        <div style={{color:accent,letterSpacing:4,fontWeight:700,fontSize:25}}>{shot.section}</div>
        <div style={{fontFamily:displayFont,fontWeight:800,fontSize:index===0?119:97,letterSpacing:index===0?-1.5:-.5,
          lineHeight:.89,marginTop:11,textShadow:'0 4px 22px #0b182b77',maxWidth:875,textWrap:'balance'}}>
          {heading}
        </div>
      </div>
    </div>
    {shot.id==='flex' && <Tag label="TEKUKAN BERULANG" left={74} top={1260} color={accent} opacity={ramp(f,20,37)}/>}
    {shot.id==='stress' && <Tag label="ZONA TEKUKAN" value="Transisi kaku → lentur" left={75} top={1200} color={accent} opacity={ramp(f,35,56)}/>}
    {shot.id==='cutaway' && <Tag label="SERABUT TEMBAGA" value="Potongan diperbesar" right={116} top={1227} color={accent} opacity={ramp(f,55,75)}/>}
    {shot.id==='fatigue' && <Tag label="RETAK → PUTUS" left={78} top={1225} color={accent} opacity={ramp(f,60,92)}/>}
    {shot.id==='route' && <Tag label="LENGKUNG LONGGAR" right={116} top={1280} color={accent} opacity={ramp(f,73,102)}/>}
    {shot.id==='braid' && <Tag label="PELINDUNG PANGKAL" left={76} top={1227} color={accent} opacity={ramp(f,13,31)*(1-ramp(f,93,116))}/>}
    {shot.id==='replace' && f<86 && <Tag label="KABEL RUSAK" left={76} top={1135} color="#ffba94" opacity={ramp(f,7,20)*(1-ramp(f,60,86))}/>}
    {shot.id==='replace' && f>135 && <Tag label="DAYA STABIL" right={116} top={1205} color={accent} opacity={ramp(f,135,150)}/>}
    {showCaptions && <Captions cues={cues}/>}
    {fade > 0 && <AbsoluteFill style={{background:'linear-gradient(112deg, transparent 14%, #ffd898 48%, #f5b76d 53%, transparent 85%)',
      opacity:.47*fade, transform:`translateX(${(1-clamp(fade))*115-55}%)`,mixBlendMode:'screen'}}/>}
  </DesignSpace>;
}

export function Episode001({profile='software',audio=null,captions=true,pixelRatio=1}: EpisodeProps) {
  useEpisodeFonts();
  return <AbsoluteFill style={{background:'#232f43'}}>
    <Stage makeWorld={world} profile={profile} pixelRatio={pixelRatio}/>
    <Graphics showCaptions={captions}/>
    {audio && <Audio src={staticFile(audio)}/>}
  </AbsoluteFill>;
}
