import * as T from 'three';
import {NOINK} from '../../engine/post/ink';
import {box, flat, FlexTube, hardEdges, paintTexture, place, standard} from '../../engine/props';
import {lerp, ramp} from '../../engine/timing';

const shell = '#38516b';
const brass = ['#ffae6e','#fbc68c','#db794e','#ffca93','#df8665','#f4a86d'];

function center(length: number, bend: number, radius: number, u: number, v: T.Vector3) {
  const s = length * u;
  const turn = bend * (s - radius * (1 - Math.exp(-s / radius)));
  return v.set(s * (1 - .23 * Math.abs(bend) * u), -turn, 0);
}

export function makeConnector(parent: T.Object3D, color = '#3e6074') {
  const group = place(parent,new T.Group());
  hardEdges(box(group,[.67,.35,.67],standard(color,.52),-.31,0,0,.08),.55);
  box(group,[.43,.11,.42],standard('#b8cfcd',.36,.44),-.79,0,0,.045);
  box(group,[.13,.07,.32],standard('#252e3e',.6),-1.005,0,0,.025);
  box(group,[.088,.353,.68],standard('#82a7a8',.54),-.55,0,0,.026);
  const guard = standard('#476f80');
  for (let n = 0; n < 4; n++) {
    const width = .36 - n * .046;
    box(group,[.051,.18 - n*.012,width],guard,-.065 + n*.045,0,0,.025);
  }
  return group;
}

export function braidMaterial() {
  const map = paintTexture(128,128,g => {
    g.fillStyle = '#37597a';
    g.fillRect(0,0,128,128);
    for (let i = -4; i < 9; i++) {
      for (let j = 0; j < 8; j++) {
        g.save();
        g.translate(i * 24 + (j % 2) * 12,j*16 + 5);
        g.rotate(j % 2 ? .53 : -.53);
        const gradient = g.createLinearGradient(0,-5,0,5);
        gradient.addColorStop(0,'#283750');
        gradient.addColorStop(.42, j % 2 ? '#8cbcc3' : '#6886a2');
        gradient.addColorStop(1,'#31445d');
        g.fillStyle = gradient;
        g.fillRect(-13,-5,25,10);
        g.restore();
      }
    }
  });
  map.wrapS = T.RepeatWrapping;
  map.repeat.set(5,1);
  return new T.MeshStandardMaterial({map, color:'#d3ebee', roughness:.82});
}

type CablePose = {
  length: number;
  bend: number;
  radius: number;
  opened?: number;
  crack?: number;
  frayed?: number;
  pulse?: number;
  stress?: number;
  braided?: boolean;
};

export class Cable {
  readonly root: T.Group;
  private readonly jacket: FlexTube;
  private readonly lining: FlexTube;
  private readonly wires: FlexTube[];
  private readonly strands: {tube: FlexTube; tail: FlexTube; tip: T.Mesh; oy: number; oz: number}[];
  private readonly beads: T.Mesh[];
  private readonly dots: T.Mesh[];
  private readonly jacketMat = standard(shell,.68);
  private readonly braidMat?: T.Material;
  private readonly p = new T.Vector3();

  constructor(parent: T.Object3D, private readonly macro = false, braid = false, private readonly scaleRadius = 1) {
    this.root = place(parent,new T.Group());
    makeConnector(this.root);
    this.jacket = place(this.root,new FlexTube(this.jacketMat,42,16));
    if (braid) this.braidMat = braidMaterial();
    this.lining = place(this.root,new FlexTube(new T.MeshStandardMaterial({
      color:'#91bcc0', roughness:.85, side:T.DoubleSide,
    }),36,12));
    this.wires = ['#749e9d','#fb774b','#e0b855'].map(color => place(this.root,new FlexTube(standard(color),32,9)));
    this.strands = Array.from({length: macro ? 7 : 3},(_,n) => {
      const a = n * 2.4;
      const r = n === 0 ? 0 : .043 + (n % 2) * .018;
      const mat = standard(brass[n % brass.length],.42,.18);
      const tip = place(this.root,new T.Mesh(new T.SphereGeometry(.019,8,6),mat));
      return {tube:place(this.root,new FlexTube(mat,27,7)), tail:place(this.root,new FlexTube(mat,25,7)),
        tip,oy:r*Math.cos(a),oz:r*Math.sin(a)};
    });
    this.beads = Array.from({length:8}, () => {
      const mat = new T.MeshBasicMaterial({color:'#ffe2a1'});
      const bead = place(this.root,new T.Mesh(new T.SphereGeometry(.022,10,7),mat));
      bead.layers.set(NOINK);
      return bead;
    });
    this.dots = Array.from({length:11}, (_,i) => {
      const mat = new T.MeshBasicMaterial({color:i < 5 ? '#ffc453' : '#f57952'});
      const marker = place(this.root,new T.Mesh(new T.SphereGeometry(.023,8,6),mat));
      marker.layers.set(NOINK);
      return marker;
    });
  }

  pose(o: CablePose) {
    const opened = o.opened ?? 0;
    const crack = o.crack ?? 0;
    const frayed = o.frayed ?? 0;
    const r = (this.macro ? .201 : .085) * this.scaleRadius;
    const path = (u: number,v: T.Vector3) => center(o.length,o.bend,o.radius,u,v);
    this.jacket.material = o.braided && this.braidMat ? this.braidMat : this.jacketMat;
    const sleeveEnd = frayed ? .19 : 1;
    this.jacket.pose(path,r,0,sleeveEnd,Math.PI*opened*.8,Math.PI*2-Math.PI*opened*.38);
    this.jacket.material.side = opened > .01 ? T.DoubleSide : T.FrontSide;
    this.lining.visible = opened > .02 || frayed > 0;
    this.lining.position.y = -opened*.08;
    this.lining.pose(path,r*.85,0,frayed ? .25 : .97,Math.PI*opened*.97,Math.PI*2-Math.PI*opened*.49);
    this.wires.forEach((wire,i) => {
      wire.visible = opened > .03;
      if (!wire.visible) return;
      const exposed = i === 1 ? lerp(1,.24,opened) : .94;
      wire.pose((u,v) => {
        path(u,v);
        v.y += (i-1) * (.065 + .11*opened);
        v.z += (i-1) * .03 + .11*opened;
        return v;
      },.063, .025,exposed);
    });
    this.strands.forEach(({tube,tail,tip,oy,oz},i) => {
      const show = opened > .05 || frayed > 0;
      const breakAt = .27 + (i%4)*.019;
      const gap = .08 * ramp(crack,i*.1, .34+i*.1);
      const begin = frayed ? .14 : .19;
      const end = frayed ? .31 + i*.026 : .94;
      tube.visible = show;
      tail.visible = show && gap > .003 && !frayed;
      tip.visible = show;
      if (!show) return;
      const strand = (u: number,v: T.Vector3) => {
        path(u,v);
        const theta = u * 8;
        v.y += (oy * Math.cos(theta) - oz * Math.sin(theta)) * (1 + opened*.57) + opened*.1;
        v.z += (oz * Math.cos(theta) + oy * Math.sin(theta)) * (1 + opened*.57) + opened*.16;
        if (frayed) {
          v.y += (i-1) * Math.max(0,u-.18)*.65;
          v.z += (1-i) * Math.max(0,u-.2)*.36;
        }
        return v;
      };
      tube.pose(strand,this.macro ? .021 : .012,begin,gap > .003 && !frayed ? breakAt - gap*.5 : end);
      if (tail.visible) tail.pose(strand,.020,breakAt + gap*.5,end);
      strand(tail.visible ? breakAt - gap*.5 : end,tip.position);
      tip.scale.setScalar(this.macro ? 1 : .58);
    });
    this.beads.forEach((bead,i) => {
      const u = ((o.pulse ?? 0) - i*.042 + 10) % 1;
      bead.visible = Boolean(o.pulse) && opened > .3 && (crack < .35 || u < .255) && u > .16;
      path(u,bead.position);
      bead.position.y += .09;
      bead.position.z += .26;
    });
    this.dots.forEach((dot,i) => {
      const a = o.stress ?? 0;
      dot.visible = a > .01;
      if (!dot.visible) return;
      const u = .012 + i*.038*(1+.15*a);
      path(u,this.p);
      dot.position.set(this.p.x,this.p.y + r*.67 + .035*a,this.p.z+r*.73);
      dot.scale.setScalar(.6 + a*(1-i*.055));
    });
  }
}

export function phone(parent: T.Object3D) {
  const root = place(parent,new T.Group());
  const body = box(root,[1.37,.183,2.18],standard('#327b78',.37,.31),0,0,0,.105);
  hardEdges(body,.56);
  box(root,[1.279,.062,2.077],standard('#1d2b39',.47),0,.089,0,.074);
  box(root,[1.19,.025,1.97],standard('#172c40',.36),0,.126,-.005,.057);
  box(root,[.32,.055,.016],flat('#172733'),0,0,1.095,.007);
  box(root,[.014,.054,.33],standard('#82aba5'),.694,.004,-.45,.007);
  const image = document.createElement('canvas');
  image.width = 276;
  image.height = 450;
  const ctx = image.getContext('2d')!;
  const map = new T.CanvasTexture(image);
  map.colorSpace = T.SRGBColorSpace;
  const surface = new T.Mesh(new T.PlaneGeometry(1.16,1.895),new T.MeshBasicMaterial({map,toneMapped:false}));
  surface.rotation.x = -Math.PI/2;
  surface.layers.set(NOINK);
  place(root,surface,0,.142,-.017);
  let last = '';
  return {
    root,
    display(active: boolean, healthy = false) {
      const key = `${active}${healthy}`;
      if (last === key) return;
      last = key;
      const grad = ctx.createLinearGradient(0,0,276,450);
      grad.addColorStop(0,active ? '#174d54' : '#1e3448');
      grad.addColorStop(1,'#101f35');
      ctx.fillStyle = grad;
      ctx.fillRect(0,0,276,450);
      ctx.fillStyle = '#ffffff12';
      ctx.beginPath();
      ctx.arc(205,145,143,0,Math.PI*2);
      ctx.fill();
      ctx.strokeStyle = '#9acac177';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.roundRect(56,192,155,66,15);
      ctx.stroke();
      ctx.fillStyle = '#9acac1';
      ctx.fillRect(211,211,8,27);
      ctx.fillStyle = active ? '#a7efad' : '#e98c68';
      ctx.beginPath();
      ctx.roundRect(64,200,active ? (healthy ? 137 : 40) : 13,50,7);
      ctx.fill();
      if (active) {
        ctx.fillStyle = '#f0ffe6';
        ctx.beginPath();
        ctx.moveTo(144,178); ctx.lineTo(119,221); ctx.lineTo(140,221);
        ctx.lineTo(132,265); ctx.lineTo(162,218); ctx.lineTo(143,218);
        ctx.closePath(); ctx.fill();
      }
      ctx.fillStyle = '#b4d5d1';
      ctx.font = '700 17px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(active ? 'MENGISI DAYA' : 'DAYA TERPUTUS',138,303);
      map.needsUpdate = true;
    },
  };
}

export function pinchHand(parent: T.Object3D) {
  const map = paintTexture(520,400,g => {
    const outline = new Path2D('M522 350 L328 310 Q295 315 264 299 L139 246 Q115 235 119 215 Q123 193 148 197 L208 210 L159 152 Q143 130 158 112 Q171 98 192 111 L241 153 L221 101 Q218 72 242 70 Q263 68 276 91 L311 150 Q359 144 389 172 L520 179Z');
    g.lineJoin = 'round';
    g.strokeStyle = '#32253d'; g.lineWidth = 13;
    g.fillStyle = '#f8bc83'; g.fill(outline); g.stroke(outline);
    g.strokeStyle = '#bd6f60'; g.lineWidth = 6; g.lineCap = 'round';
    g.stroke(new Path2D('M239 153 L270 187 M208 210 L252 224 M309 150 L329 176'));
    const cuff = new Path2D('M432 173 L520 176 L520 351 L407 331 Q399 246 432 173Z');
    g.fillStyle = '#6bc4a3'; g.strokeStyle = '#32253d'; g.lineWidth = 11; g.fill(cuff); g.stroke(cuff);
  });
  const mesh = place(parent,new T.Mesh(new T.PlaneGeometry(2.68,2.06),new T.MeshLambertMaterial({
    map,alphaTest:.45,side:T.DoubleSide,color:'#fff2dc',
  })));
  mesh.layers.set(NOINK);
  return mesh;
}
