import * as T from 'three';
import {Kiko} from '../../engine/actor';
import {box, flat, groundShadow, hardEdges, paintTexture, place, standard} from '../../engine/props';
import {aimCamera, cameraAt, envelope, lerp, ramp, type CameraKey} from '../../engine/timing';
import {Cable, phone, pinchHand} from './cable';
import data from '../../../episodes/001/episode.json';

const stageColor = '#294754';
const macroColor = '#242d43';
const copperColor = '#3b2f47';
const cream = '#f2d3a4';
const TAU = Math.PI * 2;

const cameras: Record<string, CameraKey[]> = {
  hook: [
    {at:0, eye:[3.2,3.25,7.6],target:[.22,1.02,.1],fov:34,roll:-.06},
    {at:.36,eye:[2.05,3.38,6.8],target:[.28,1.01,.31],fov:34,roll:-.018},
    {at:1,eye:[1.18,3.05,5.75],target:[.41,.81,.43],fov:36,roll:.033},
  ],
  flex: [
    {at:0,eye:[.88,1.96,5.24],target:[-.12,1.06,0],fov:37,roll:.09},
    {at:1,eye:[.21,1.72,4.14],target:[-.22,1.02,0],fov:36,roll:-.12},
  ],
  stress: [
    {at:0,eye:[-.55,1.52,3.56],target:[-.28,1.06,0],fov:34,roll:-.10},
    {at:1,eye:[.23,1.78,2.9],target:[-.22,1.01,0],fov:37,roll:.03},
  ],
  cutaway: [
    {at:0,eye:[.4,1.88,3.69],target:[.42,1.01,0],fov:35,roll:.16},
    {at:.49,eye:[.62,1.72,3.38],target:[.48,1.07,0],fov:33,roll:.04},
    {at:1,eye:[.93,1.65,3.3],target:[.60,1.09,.07],fov:34,roll:-.09},
  ],
  fatigue: [
    {at:0,eye:[1.37,1.70,3.46],target:[.54,1.12,.10],fov:31,roll:-.18},
    {at:.56,eye:[.78,1.42,2.93],target:[.49,1.06,.16],fov:32,roll:.025},
    {at:1,eye:[.54,1.30,2.7],target:[.48,1.03,.16],fov:30,roll:.08},
  ],
  failure: [
    {at:0,eye:[2.29,3.05,5.26],target:[.21,.63,.51],fov:36,roll:.06},
    {at:1,eye:[1.13,3.70,4.45],target:[.44,.48,.44],fov:37,roll:-.045},
  ],
  grip: [
    {at:0,eye:[1.26,2.05,4.83],target:[-.21,1.02,.13],fov:34,roll:.02},
    {at:1,eye:[.86,1.69,4.66],target:[.18,1.06,.18],fov:34,roll:-.076},
  ],
  route: [
    {at:0,eye:[1.8,5.95,4.3],target:[.24,.23,.56],fov:35,roll:-.07},
    {at:1,eye:[.49,6.5,3.8],target:[.48,.29,.65],fov:35,roll:.12},
  ],
  braid: [
    {at:0,eye:[-.50,2.0,3.49],target:[-.26,1.10,.01],fov:36,roll:-.15},
    {at:.5,eye:[.05,1.62,3.16],target:[-.15,1.02,.07],fov:37,roll:0},
    {at:1,eye:[1.17,1.99,3.53],target:[.42,1.07,.06],fov:34,roll:.10},
  ],
  replace: [
    {at:0,eye:[2.4,3.27,6.27],target:[.22,.89,.28],fov:36,roll:.07},
    {at:1,eye:[1.29,2.84,6.77],target:[.21,.90,.2],fov:34,roll:-.025},
  ],
};

const woodMap = () => paintTexture(768,560,g => {
  g.fillStyle='#dbad80';
  g.fillRect(0,0,768,560);
  for (let y=0;y<560;y++) {
    const edge = y % 112;
    const v = Math.sin(y*.65) * 5 + Math.sin(y*.07)*8 + (edge < 2 ? -25 : 0);
    g.fillStyle = `rgb(${219+v},${171+v},${126+v})`;
    g.fillRect(0,y,768,1);
  }
  for (let i=0;i<160;i++) {
    const x = (i*153.42)%768;
    const y = (i*71.19)%560;
    g.strokeStyle = i%2 ? '#915a441f' : '#fff2c72f';
    g.beginPath(); g.moveTo(x,y); g.bezierCurveTo(x+24,y-3,x+35,y+3,x+70+(i%7)*18,y+1); g.stroke();
  }
});

function makeDesk(root: T.Group) {
  const desk = new T.MeshStandardMaterial({map:woodMap(),roughness:.86,color:'#d6b69c'});
  box(root,[15,.18,10],desk,0,-.09,-1.76);
  const floorMat = standard('#39616b',.91);
  const wall = box(root,[19,10,.3],floorMat,0,3.9,-4.9);
  hardEdges(wall,.32);
  box(root,[13,.24,.82],standard('#34525f'),0,1.98,-4.4);
  box(root,[13,.07,.83],standard('#719493'),0,2.13,-4.4);

  const windowMap = paintTexture(512,420,g => {
    const grad=g.createLinearGradient(0,0,0,420);
    grad.addColorStop(0,'#6193a0'); grad.addColorStop(.52,'#d1b19f'); grad.addColorStop(1,'#ecae7e');
    g.fillStyle=grad;g.fillRect(0,0,512,420);
    g.fillStyle = '#ffe1a8';
    g.beginPath();g.arc(332,170,72,0,TAU);g.fill();
    for(let i=0;i<13;i++) {
      g.fillStyle = ['#728b91','#607c87','#779093'][i%3];
      const h = 28+(i*67)%126;
      g.fillRect(i*45,420-h,48,h);
      g.fillStyle='#efc29a7c';
      for(let k=0;k<2;k++) g.fillRect(i*45+8+k*16,435-h,5,8);
    }
    g.fillStyle='#e5b18e77';
    for(let i=0;i<3;i++) g.fillRect(0,110+i*9,(i+3)*110,3);
  });
  const frame = standard('#203f51');
  box(root,[3.7,3.16,.3],frame,-.95,3.55,-4.67,.06);
  const win = new T.MeshBasicMaterial({map:windowMap});
  place(root,new T.Mesh(new T.PlaneGeometry(3.52,2.98),win),-.95,3.55,-4.505);
  box(root,[.08,3.07,.18],frame,-.94,3.55,-4.43);
  box(root,[3.56,.075,.16],frame,-.94,3.72,-4.43);

  const books = ['#d7896d','#80a596','#d3b172','#577b9b','#b86768'];
  for (const direction of [-1,1]) {
    books.forEach((color,i) => {
      const x=direction*3.4 + i*.25;
      const h=.56 + (i*7%5)*.11;
      box(root,[.19,h,.39],standard(color),x,2.15+h*.5,-4.32,.02);
      box(root,[.018,.025,.32],standard('#e2c79e'),x,2.16+h*.78,-4.115,.008);
    });
  }

  const mat = standard('#50857d',.9);
  groundShadow(root, 3.95,2.6,.48,.26,.32);
  box(root,[3.08,.045,2.58],mat,.50,.026,.13,.022);
  const line=flat('#a2ad8a');
  for (let x=0;x<9;x++) {
    box(root,[.012,.002,.075],line,-.88+x*.34,.051,1.31,.001);
  }

  const mug = place(root,new T.Group(),2.05,.32,-1.55);
  const terracotta=standard('#d07861',.56);
  place(mug,new T.Mesh(new T.CylinderGeometry(.31,.23,.64,24,1,true),new T.MeshStandardMaterial({color:'#d07861',side:T.DoubleSide,roughness:.53})));
  place(mug,new T.Mesh(new T.CylinderGeometry(.246,.219,.014,24),standard('#65464c')) ,0,.14,0);
  const handle=place(mug,new T.Mesh(new T.TorusGeometry(.18,.055,8,18),terracotta),.29,.02,0);
  handle.rotation.z=.22;
  groundShadow(root,1.16,.89,2.04,-1.57,.6);
  const note = box(root,[.79,.035,.63],standard('#dfc480'),-1.67,.025,.68,.021);
  note.rotation.y=.2;
  for(let i=0;i<3;i++) {
    const notebookLine=box(root,[.50-i*.06,.004,.014],standard('#a98e65'),-1.67,.048,.51+i*.08,.001);
    notebookLine.rotation.y=.2;
  }
  const pencil=box(root,[.86,.036,.06],standard('#d57a54'),-1.53,.063,.24,.018);
  pencil.rotation.y=.31;
  return root;
}

function makeBackdrop(root: T.Group) {
  const map = paintTexture(700,700,g => {
    const grad = g.createRadialGradient(350,310,12,350,310,485);
    grad.addColorStop(0,'#5a637a');grad.addColorStop(.55,'#383f59');grad.addColorStop(1,'#27283e');
    g.fillStyle=grad;g.fillRect(0,0,700,700);
    g.strokeStyle='#bdc7ee16';
    g.lineWidth=1.4;
    for(let i=0;i<22;i++) {
      g.beginPath();g.moveTo(0,i*34);g.lineTo(700,i*34);g.stroke();
      g.beginPath();g.moveTo(i*34,0);g.lineTo(i*34,700);g.stroke();
    }
    g.strokeStyle='#b9c6df23';
    for(let n=1;n<=4;n++) {g.beginPath();g.arc(350,350,48*n,0,TAU);g.stroke();}
  });
  place(root,new T.Mesh(new T.PlaneGeometry(10,10),new T.MeshBasicMaterial({map})),0,1.45,-2.6);
  const plinth = box(root,[7,.15,2.75],standard('#42445e'),.15,-.30,-.35,.05);
  hardEdges(plinth,.4);
  for(let i=0;i<10;i++) {
    box(root,[.009,.006,.122],flat('#79778c'),-1.45+i*.35,-.22,.93,.001);
  }
  groundShadow(root,4.45,1.25,.20,0,.73,-.215);
}

const probeMaterial = () => new T.MeshBasicMaterial({color:'#f7be63',transparent:true,opacity:.8,depthWrite:false});
function marker(parent: T.Object3D, radius: number) {
  const mesh = new T.Mesh(new T.TorusGeometry(radius,.009,6,38,.82*TAU),probeMaterial());
  return place(parent,mesh);
}

export class EpisodeWorld {
  readonly root = new T.Group();
  private readonly bench = makeDesk(place(this.root,new T.Group()));
  private readonly inspection = place(this.root,new T.Group());
  private readonly host = new Kiko(this.bench);
  private readonly handset = phone(this.bench);
  private readonly cable = new Cable(this.bench);
  private readonly damaged = new Cable(this.bench);
  private readonly diagnostic = new Cable(this.inspection,true,true);
  private readonly hand = pinchHand(this.inspection);
  private readonly port = place(this.inspection,new T.Group());
  private readonly clip = place(this.bench,new T.Group());
  private readonly halo = marker(this.inspection,.372);
  private readonly ring = marker(this.inspection,.48);
  private readonly sparks: T.Mesh[];
  private readonly key = place(this.root,new T.DirectionalLight('#ffddb0',2.65),-4,6,4);
  private readonly sky = place(this.root,new T.HemisphereLight('#d6edee','#4b436c',1.66),0,3,0);
  private readonly rim = place(this.root,new T.DirectionalLight('#94bdfa',2.22),3,2,-3);

  constructor() {
    makeBackdrop(this.inspection);
    place(this.root,new T.DirectionalLight('#f7ae7d',.68),-3,4,-3);
    this.handset.root.position.set(.64,.15,-.17);
    this.cable.root.scale.setScalar(.64);
    this.damaged.root.scale.setScalar(.76);
    this.cable.root.rotation.set(Math.PI/2,-Math.PI/2,0,'YXZ');
    this.damaged.root.rotation.set(Math.PI/2,-Math.PI/2,0,'YXZ');
    this.port.position.set(-1.8,1.08,0);
    const slab = box(this.port,[1.09,.79,1.01],standard('#3b8784',.5),0,0,0,.12);
    hardEdges(slab,.65);
    box(this.port,[.019,.13,.46],flat('#202737'),.54,0,0,.007);
    box(this.port,[1.06,.09,.9],standard('#192a3c',.5),0,.4,0,.042);
    const clipMat = standard('#d49c5a',.53);
    box(this.clip,[.45,.065,.37],clipMat,0,.043,0,.035);
    box(this.clip,[.35,.14,.08],clipMat,0,.087,.144,.033);
    box(this.clip,[.35,.14,.08],clipMat,0,.087,-.144,.033);
    this.clip.position.set(1.06,.054,1.99);
    this.clip.rotation.y=-.32;
    this.sparks = Array.from({length:10},()=>place(this.inspection,new T.Mesh(new T.BoxGeometry(.022,.09,.018),flat('#ffe9a1'))));
  }

  update(scene: T.Scene,camera: T.PerspectiveCamera,frame: number) {
    const shot = data.shots.find(s=>frame < s.end) ?? data.shots.at(-1)!;
    const f = frame-shot.start;
    const progress = f/(shot.end-shot.start-1);
    const onDesk = ['hook','failure','route','replace'].includes(shot.id);
    const snap = shot.id === 'fatigue' ? Math.max(...[98,138,162].map(at=>envelope(f,at,8))) : 0;
    const pose = cameraAt(cameras[shot.id],progress);
    const focus = aimCamera(camera,pose,snap*(f%2 ? -.01 : .01));
    const shade = onDesk ? stageColor : shot.id==='fatigue' ? copperColor : macroColor;
    if (!(scene.background instanceof T.Color)) scene.background = new T.Color(shade);
    else scene.background.set(shade);
    if (!(scene.fog instanceof T.Fog)) scene.fog = new T.Fog(shade,8,25);
    scene.fog.color.set(shade);
    this.key.intensity = onDesk ? 2.6 : 2.35;
    this.sky.intensity = onDesk ? 1.78 : 1.54;
    this.rim.intensity = onDesk ? 1.49 : 2.72;
    this.bench.visible = onDesk;
    this.inspection.visible = !onDesk;
    if (onDesk) this.desk(shot.id,f,frame,camera,shot.cues.some(c=>frame>=c.start && frame<c.end));
    else this.macro(shot.id,f,camera,snap);
    const blur = shot.id==='route' ? 8 : onDesk ? 13 : 16;
    return {focus,blur};
  }

  private desk(id: string,f: number,frame: number,camera: T.Camera,talk: boolean) {
    const ending = id==='replace';
    const routing = id==='route';
    const working = id==='hook' ? (f<52 && f>=14) || (f>=74 && f<95) : ending ? f>=136 : routing || (id==='failure' && f<82);
    this.handset.display(working,ending);
    this.host.card.visible = !routing && id!=='failure';
    this.host.shadow.visible = this.host.card.visible;
    this.host.pose(camera,frame,ending ? f>=136?'wink':'proud' : working?'curious':'worried',.25+.65*ramp(f,24,85),talk,-.63,-1.57,ending?.95:.84);
    this.clip.visible = routing;
    if (routing) {
      const slide = ramp(f,71,113);
      this.clip.position.set(lerp(1.98,1.095,slide),.054,lerp(2.54,2.45,slide));
      this.clip.rotation.y=-.6*slide;
    }
    const snapOut = ending ? 1-ramp(f,90,136) : 0;
    this.cable.root.position.set(.64,.16,1.555+snapOut*.53);
    this.cable.root.visible = !ending || f>=84;
    this.cable.pose({
      length:routing?1.95:2.25,
      radius:routing?lerp(.20,.75,ramp(f,36,102)):.44,
      bend:routing?lerp(-.92,.61,ramp(f,36,102)) : ending?.42 : lerp(.64,.84,.5+.5*Math.sin(f*.069)),
    });
    this.damaged.root.visible=ending && f<98;
    if (ending) {
      const shelf=ramp(f,22,89);
      this.damaged.root.position.set(lerp(-.65,-2.7,shelf),.25+.32*Math.sin(Math.PI*shelf),lerp(1.34,1.95,shelf));
      this.damaged.root.rotation.y=lerp(.30,-.69,shelf);
      this.damaged.pose({length:2.25,bend:.45,radius:.2,frayed:1});
    }
  }

  private macro(id: string,f: number,camera: T.Camera,snap: number) {
    const flexCycle = .5-.5*Math.cos((f-2)/48*TAU);
    const isFlex=id==='flex', isStress=id==='stress', isCut=id==='cutaway';
    const isFatigue=id==='fatigue', isGrip=id==='grip', isBraid=id==='braid';
    let bend=.23;
    if (isFlex) bend=lerp(-.085,.76,flexCycle);
    if (isStress) bend=lerp(.13,.78,ramp(f,10,89))-.02*Math.sin(f*.1);
    if (isCut) bend=lerp(.70,.16,ramp(f,0,54));
    if (isFatigue) bend=lerp(.13,.53,.5+.5*Math.sin(f*.16))+.1*ramp(f,108,169);
    if (isBraid) bend=lerp(.19,.67,ramp(f,31,114));
    const pull=isGrip?ramp(f,72,117):0;
    this.diagnostic.root.position.set(-.42+.82*pull,1.14,0);
    this.port.visible=isGrip;
    this.port.position.x=-1.63;
    this.hand.visible=isGrip;
    if (isGrip) {
      this.hand.position.set(-.10+.82*pull+2.46*(1-ramp(f,4,35)),1.37,.45);
      this.hand.quaternion.copy(camera.quaternion);
      this.hand.rotateZ(-.09);
    }
    const cut=isCut ? ramp(f,4,63) : isFatigue ? lerp(.94,1,ramp(f,18,52)) : 0;
    const crack=isFatigue ? lerp(.09,.58,ramp(f,48,111))+.42*ramp(f,111,167) : 0;
    this.diagnostic.pose({
      length:isGrip?2.5:3.08, bend, radius:isBraid?.66:.26, opened:cut, crack,
      pulse:isCut && f>65 ? (f-65)*.017 : isFatigue ? f*.027 : 0, stress:isStress?ramp(f,30,75):0,
      braided:isBraid,
    });
    this.halo.visible=isStress && f>35;
    this.ring.visible=isStress && f>44;
    if (isStress) {
      const pulse=.5+.5*Math.sin(f*.10);
      this.halo.position.set(-.26,1.08,.251);
      this.ring.position.copy(this.halo.position);
      this.halo.quaternion.copy(camera.quaternion);
      this.ring.quaternion.copy(camera.quaternion);
      this.halo.rotateZ(f*.028);
      this.ring.rotateZ(-f*.013);
      this.halo.scale.setScalar(1+.055*pulse);
      this.ring.material.opacity = .18 + .32*pulse;
    }
    for(const [i,spark] of this.sparks.entries()) {
      spark.visible=snap>.02;
      if(!spark.visible) continue;
      const a=i/this.sparks.length*TAU;
      const spread=.29+(1-snap)*.62;
      spark.position.set(.50+Math.cos(a)*spread,1.05+Math.sin(a)*spread,.36);
      spark.rotation.z=a-Math.PI/2;
      spark.scale.setScalar(snap);
    }
  }
}
