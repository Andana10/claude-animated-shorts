import {Composition} from 'remotion';
import {AmbientLight,DirectionalLight,Group,PerspectiveCamera,Scene} from 'three';
import {box,hardEdges,place,standard} from './engine/props';
import {Stage} from './engine/Stage';
import {Episode001} from './episodes/001/Episode';
import data from '../episodes/001/episode.json';

const smokeWorld = () => {
  const root = new Group();
  const cube = box(root,[1.05,1.05,1.05],standard('#ee7c54'),0,0,0,.12);
  hardEdges(cube);
  return {
    root,
    update(scene: Scene,camera: PerspectiveCamera,frame: number) {
      cube.rotation.set(.32+frame*.081,frame*.13,.14);
      camera.position.set(0,1,4.6);
      camera.lookAt(0,0,0);
      camera.updateMatrixWorld();
      scene.background = null;
      return {focus:4.7,blur:3};
    },
  };
};
const makeSmoke = () => {
  const world = smokeWorld();
  place(world.root,new AmbientLight('#b9d9e0',2.2));
  place(world.root,new DirectionalLight('#ffdbc6',2.6),3,2,4);
  return world;
};
const Smoke = () => <Stage makeWorld={makeSmoke} profile="software"/>;
const audio = 'episode-001/guide-mix.m4a';

export function Root() {
  return <>
    <Composition id="Smoke" component={Smoke} width={270} height={480} fps={30} durationInFrames={24}/>
    <Composition id="EP001-Preview" component={Episode001} width={540} height={960}
      durationInFrames={data.durationFrames} fps={data.fps} defaultProps={{profile:'software',audio,captions:true}}/>
    <Composition id="EP001-Final" component={Episode001} width={1080} height={1920}
      durationInFrames={data.durationFrames} fps={data.fps} defaultProps={{profile:'cinema',audio,captions:true}}/>
  </>;
}
