# Kenapa Hal Sehari-hari Bisa Begitu?

A reusable Remotion and Three.js production kit for 45–60 second Indonesian animated explainers. Episode 001, **Kenapa Kabel Charger Selalu Rusak di Bagian Ini?**, runs for 54 seconds. Kiko is the original recurring host.

## Quick start

Use Node.js 22 or later, npm, and FFmpeg with `ffprobe`. Install Chromium or Chrome for a system browser, and install eSpeak NG only if you want to regenerate the included guide narration locally. On Debian 13, the packages are `chromium ffmpeg espeak-ng`. Chrome Headless Shell is a Remotion-managed fallback when no supported system executable is detected.

```sh
npm ci
npm run check
npm run doctor
npm run smoke
npm run studio
```

The lockfile pins the complete dependency graph. Remotion's own license applies to its packages. [Remotion license](https://www.remotion.dev/docs/license)

## Render Episode 001

The working directory is the project root. These commands use the included guide mix. Both builds are 9:16 H.264 at 30 fps with Indonesian subtitles burned in.

```sh
npm run preview:001
npm run qa:001
npm run final:001
npm run qa:001 -- renders/episode-001-final.mp4 renders/qa-final
```

By default the preview uses a native **540×960** WebGL buffer. The final composition uses **1080×1920** and adds the upstream normal/depth ink pass, two-stage depth-of-field gather, and selective bloom. Both render a lit 3D set and the same character and object animation. The preview uses geometric edge lines and a smaller depth-of-field kernel.

Software rendering may take several minutes for a 54-second video. On GPU-less Linux, the runner defaults to Chromium ANGLE with SwiftShader (`swangle`). Set `RENDER_PROFILE=software` for a lower-cost full-resolution render. Use `RENDER_CONCURRENCY=1` when memory is tight. `RENDER_PIXEL_RATIO=.55` reduces the WebGL buffer for CPU-only review while preserving the composition's output size, frame rate and native-resolution captions. On a GPU-equipped Linux system, test `RENDER_GL=angle-egl npm run doctor` before using that backend for a render. `BROWSER_EXECUTABLE` accepts an absolute path. On macOS or Windows, the runner uses Remotion's bundled browser by default. [Remotion GL options](https://www.remotion.dev/docs/gl-options)

```sh
RENDER_PROFILE=software npm run final:001
SILENT=1 npm run preview:001 -- renders/episode-001-silent.mp4
SILENT=1 npm run qa:001 -- renders/episode-001-silent.mp4 renders/qa-silent
```

The Studio compositions use the bundled guide mix. Set their `audio` prop to `null` for a silent Studio session. Use `CAPTIONS=off` for a clean picture paired with [the SRT](episodes/001/subtitles.id.srt). To check a render window, set an inclusive frame range such as `RENDER_FRAMES=715,727` and choose an excerpt filename. Run full-length QA on complete videos. `npm run stills:001 -- renders/review 28,405,560,765,1081,1589` selects frames at preview resolution.

## Narration and sound

The bundled stereo guide mix contains local eSpeak NG Indonesian narration, an original plucked bed, and 25 frame-timed synthesized effects. The source of truth is [episode.json](episodes/001/episode.json). After editing it, regenerate the SRT, narration, storyboard and mix.

```sh
npm run prep:001
npm run voice:001
npm run check
```

For a human read, record or edit one WAV starting at episode time zero and align speech to the [narration and cue timings](episodes/001/subtitles.id.srt). Then rebuild the audio mix with the same synchronized sound design.

```sh
VOICE_WAV=/absolute/path/narration.wav npm run voice:001
```

`ESPEAK_BIN` can point to a local eSpeak NG binary. `ESPEAK_DATA` is the parent directory of `espeak-ng-data` for a portable installation. Without a mix or with `SILENT=1`, the render still includes the Indonesian captions and the narration remains available in [the script](episodes/001/narration.id.md).

## Make another episode

1. Create `episodes/NNN/episode.json` from the structure in [Episode 001](episodes/001/episode.json). Define contiguous half-open shot ranges, narration cues, and frame-indexed sound events. Keep 30 fps and 1,350–1,800 frames.
2. Generate production documents with `node scripts/episode.mjs prepare episodes/NNN`. Verify the mechanism, safety guidance, and the script against the new episode's source notes.
3. Add a scene module in `src/episodes/NNN`. Use `Stage` with a world that returns a focus distance and blur amount each frame. Reuse the Kiko rig, camera keys, textures, contacts, caption layout, and flexible tubes where appropriate.
4. Register `EPNNN-Preview` and `EPNNN-Final` in `src/root.tsx`. Accept the `profile`, `audio`, `captions`, and `pixelRatio` input props in the episode component.
5. Run `node scripts/voice.mjs episodes/NNN` for the mix. Then run `EPISODE=NNN node scripts/render.mjs preview` and `node scripts/qa.mjs episodes/NNN renders/episode-NNN-preview.mp4 renders/qa-NNN`. Review the contact sheet and the motion around slide, impact, and cut points. Use `EPISODE=NNN node scripts/render.mjs final` for the full-resolution version.

The [Codex skill](.agents/skills/indonesian-animated-shorts/SKILL.md) documents editorial and shot-review practice. [AGENTS.md](AGENTS.md) covers source and render operations. Episode 001 includes a [shot list](episodes/001/storyboard.md) and [fact-check notes](episodes/001/fact-check.md).

## Upstream

Adapted from Mr omi's `claude-animated-shorts`, pin `e3b817b6afc6cd413466d43f11ba31209e034bbf`. The upstream MIT copyright and permission notice are in [LICENSE](LICENSE). See the [upstream audit](docs/upstream-audit.md) for the reusable techniques and porting decisions. [Source repository](https://github.com/mromidev/claude-animated-shorts/tree/e3b817b6afc6cd413466d43f11ba31209e034bbf)
